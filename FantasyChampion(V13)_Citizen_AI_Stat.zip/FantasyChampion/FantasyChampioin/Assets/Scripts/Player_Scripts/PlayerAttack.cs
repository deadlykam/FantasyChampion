﻿using UnityEngine;
using System.Collections;

public class PlayerAttack : MonoBehaviour {

    public bool isAttacking = false;

    /***Projectiles***/
    public GameObject fire_ball;
    /// END ///
    
    private Animator anim;
    private GameObject leftPalm;
    private GameObject rightPalm;
    private BuildControl bc;
    private Player_Action p_a;

    // Use this for initialization
    void Start () {
        anim = GetComponentInChildren<Animator>();
        bc = GetComponent<BuildControl>();
        p_a = transform.FindChild("Action_Range").GetComponent<Player_Action>();

        //Due to making mistake in naming convention, left side is actually right and right side is actually left.
        leftPalm = anim.gameObject.transform.FindChild("Player_Armature").FindChild("Body").FindChild("Upper_Arm_R").FindChild("Fore_Arm_R").FindChild("Palm_R").gameObject;
        rightPalm = anim.gameObject.transform.FindChild("Player_Armature").FindChild("Body").FindChild("Upper_Arm_L").FindChild("Fore_Arm_L").FindChild("Palm_L").gameObject;
    }
	
	// Update is called once per frame
	void Update () {
        if (bc.build_mode != BuildControl.BUILD_MODE.BUILD && !p_a.isPanels)
        {
            //Attack(); //<--- Gives bug!
            CreateProjectile();
        }
        else
        {
            isAttacking = false;
            anim.SetBool("attack", false);
        }
    }

    void Attack() {
        if (Input.GetMouseButton(0)){
            isAttacking = true;
            anim.SetBool("attack", true);
        }
        else {
            isAttacking = false;
            anim.SetBool("attack", false);
        }
    }

    void CreateProjectile()
    {
        if (anim.GetBool("l_attack"))
        {
            GameObject fire_ball_Clone = (GameObject)Instantiate(fire_ball, leftPalm.transform.position, Quaternion.identity);
            fire_ball_Clone.transform.position = leftPalm.transform.position;
            fire_ball_Clone.transform.rotation = leftPalm.transform.rotation;
            anim.SetBool("l_attack", false);
        }

        if (anim.GetBool("r_attack"))
        {
            GameObject fire_ball_Clone = (GameObject)Instantiate(fire_ball, rightPalm.transform.position, Quaternion.identity);
            fire_ball_Clone.transform.position = rightPalm.transform.position;
            fire_ball_Clone.transform.rotation = rightPalm.transform.rotation;
            anim.SetBool("r_attack", false);
        }
    }
}
