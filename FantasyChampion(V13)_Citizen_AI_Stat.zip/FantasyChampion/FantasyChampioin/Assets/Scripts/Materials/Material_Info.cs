﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Keeps the infromation of material objects.
/// </summary>

public class Material_Info : MonoBehaviour {

    public string name;
    public float health;
    public bool alive = true;
    public GameObject material;

    //Fields for growing
    public float max_Growth;
    public float current_Growth;
    public float growth_Speed;
    public bool is_Grow;
    
    void Update()
    {
        if (is_Grow)
        {
            if (!is_Grown())
            {
                growing();
            }
        }
    }

    /// <summary>
    /// Increases the size of the material till it reaches max_Growth.
    /// </summary>
    void growing()
    {
        current_Growth += growth_Speed * Time.deltaTime;

        if (is_Grown())
        {
            current_Growth = max_Growth;
        }

        transform.localScale = new Vector3(current_Growth, current_Growth, current_Growth);
    }

    /// <summary>
    /// Checks to see if the material has grown or not.
    /// </summary>
    /// <returns></returns>
    public bool is_Grown()
    {
        if(current_Growth >= max_Growth)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Decreases the health of the material.
    /// </summary>
    /// <param name="amount">The amount by which the hp will decrease</param>
    public void health_Decrease(float amount)
    {
        health -= amount;

        if(health <= 0)
        {
            alive = false;
            Destroy(gameObject);
            //Debug.Log(name + " is dead.");
        }
    }
}
