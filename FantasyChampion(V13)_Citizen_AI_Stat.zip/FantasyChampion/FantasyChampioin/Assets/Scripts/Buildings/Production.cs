﻿using UnityEngine;
using System.Collections;

public class Production : MonoBehaviour {

    public GameObject produce;
    public int num_Of_Produce;
    public int max_Wood;
    public int max_Stone;
    public int max_Flour;
    public int c_Wood;
    public int c_Stone;
    public int c_Flour;

    private int b_Wood;
    private int b_Stone;
    private int b_Flour;

    void create_Produce()
    {
        for(int i = 0; i < num_Of_Produce; i++)
        {
            GameObject temp = (GameObject)Instantiate(produce, transform.FindChild("Produce").position, transform.FindChild("Produce").rotation);

            if (temp.GetComponent<Weapon_Info>() != null)
            {
                temp.name = temp.GetComponent<Weapon_Info>().name;
            }
            else if (temp.GetComponent<Food_Info>() != null)
            {
                temp.name = temp.GetComponent<Food_Info>().name;
            }

            temp.transform.parent = transform.FindChild("Storage").transform;
        }
        
        reset_Progress();
    }

    void reset_Progress()
    {
        b_Wood = 0;
        b_Stone = 0;
        b_Flour = 0;
    }

    bool placed_All_Mats()
    {
        if (b_Wood >= max_Wood && b_Stone >= max_Stone && b_Flour >= max_Flour)
        {
            return true;
        }

        return false;
    }

    void built_Wood()
    {
        b_Wood++;
    }

    void built_Stone()
    {
        b_Stone++;
    }

    void built_Flour()
    {
        b_Flour++;
    }

    void add_Wood(int amount)
    {
        c_Wood += amount;

        if (c_Wood >= max_Wood)
        {
            c_Wood = max_Wood;
        }
    }

    void add_Stone(int amount)
    {
        c_Stone += amount;

        if (c_Stone >= max_Stone)
        {
            c_Stone = max_Stone;
        }
    }

    void add_Flour(int amount)
    {
        c_Flour += amount;

        if(c_Flour >= max_Flour)
        {
            c_Flour = max_Flour;
        }
    }

    public void reset_Current()
    {
        c_Wood = 0;
        c_Stone = 0;
        c_Flour = 0;
    }

    public void add_Mat(string name, int amount)
    {
        if (name == "Wood")
        {
            add_Wood(amount);
        }
        else if (name == "Stone")
        {
            add_Stone(amount);
        }
        else if (name == "Flour")
        {
            add_Flour(amount);
        }
    }

    /// <summary>
    /// Checks to see if any material is required or not.
    /// </summary>
    /// <returns>True = Required, False = Not required.</returns>
    public bool is_Mat_Req()
    {
        if (c_Wood >= max_Wood && c_Stone >= max_Stone && c_Flour >= max_Flour)
        {
            return false;
        }

        return true;
    }

    /// <summary>
    /// Checks to see if wood is required.
    /// </summary>
    /// <returns>True = it is required. False = it is not required.</returns>
    public bool is_Wood_Req()
    {
        if (c_Wood >= max_Wood)
        {
            return false;
        }

        return true;
    }

    /// <summary>
    /// Returns number of wood required.
    /// </summary>
    /// <returns>int (max_Wood - c_Wood)</returns>
    public int get_Num_Wood_Req()
    {
        return (max_Wood - c_Wood);
    }

    public bool is_Stone_Req()
    {
        if (c_Stone >= max_Stone)
        {
            return false;
        }

        return true;
    }

    public int get_Num_Stone_Req()
    {
        return (max_Stone - c_Stone);
    }

    public bool is_Flour_Req()
    {
        if(c_Flour >= max_Flour)
        {
            return false;
        }

        return true;
    }

    public int get_Num_Flour_Req()
    {
        return (max_Flour - c_Flour);
    }

    /// <summary>
    /// Checks for mats
    /// </summary>
    /// <returns>True = has mats, False = Does not have it.</returns>
    public bool has_Mat()
    {
        for(int i = 0; i < transform.FindChild("Storage").childCount; i++)
        {
            if(transform.FindChild("Storage").GetChild(i).name == "Wood" || transform.FindChild("Storage").GetChild(i).name == "Stone" || transform.FindChild("Storage").GetChild(i).name == "Flour")
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Checks to see if it has the produce.
    /// </summary>
    /// <returns></returns>
    public bool has_Produce()
    {
        for (int i = 0; i < transform.FindChild("Storage").childCount; i++)
        {
            if (transform.FindChild("Storage").GetChild(i).name == produce.name)
            {
                return true;
            }
        }

        return false;
    }

    public void use_Material()
    {
        for (int i = 0; i < transform.FindChild("Storage").childCount; i++)
        {
            if (transform.FindChild("Storage").GetChild(i).GetComponent<Produce_Info>() != null)
            {
                if (transform.FindChild("Storage").GetChild(i).GetComponent<Produce_Info>().name == "Wood")
                {
                    built_Wood();
                    Destroy(transform.FindChild("Storage").GetChild(i).gameObject);
                    break;
                }
                else if (transform.FindChild("Storage").GetChild(i).GetComponent<Produce_Info>().name == "Stone")
                {
                    built_Stone();
                    Destroy(transform.FindChild("Storage").GetChild(i).gameObject);
                    break;
                }
                else if (transform.FindChild("Storage").GetChild(i).GetComponent<Produce_Info>().name == "Flour")
                {
                    built_Flour();
                    Destroy(transform.FindChild("Storage").GetChild(i).gameObject);
                    break;
                }
            }
        }

        if (placed_All_Mats())
        {
            create_Produce();
            reset_Current();
        }
    }
}
