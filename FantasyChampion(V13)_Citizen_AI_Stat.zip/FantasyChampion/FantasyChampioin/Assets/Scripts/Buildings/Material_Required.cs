﻿using UnityEngine;
using System.Collections;

public class Material_Required : MonoBehaviour {

    public string name;
    public int max_Wood;
    public int max_Stone;
    public int c_Wood;
    public int c_Stone;
    public GameObject mainBuilding;
    public bool is_InProgress;
    public int max_Spot_Engineer;
    public int max_Spot_Transporters;
    public int free_Spot_Engineer;
    public int free_Spot_Transporters;

    private int b_Wood = 0;
    private int b_Stone = 0;

	// Update is called once per frame
	void Update () {
        if (placed_All_Mats())
        {
            place_Main_Building();
        }
	}

    public void take_Spot_Engineer()
    {
        free_Spot_Engineer++;
    }

    public void take_Spot_Transporter()
    {
        free_Spot_Transporters++;
    }

    public bool isFree_Engineers()
    {
        if(free_Spot_Engineer != max_Spot_Engineer)
        {
            return true;
        }
        return false;
    }

    public bool isFree_Transporters()
    {
        if(free_Spot_Transporters != max_Spot_Transporters)
        {
            return true;
        }
        return false;
    }

    void place_Main_Building()
    {
        GameObject placement = (GameObject)Instantiate(mainBuilding, transform.position, transform.rotation);
        placement.name = placement.GetComponent<Building_Info>().name;
        placement.transform.parent = transform.parent.parent.FindChild("Buildings").transform;
        Destroy(gameObject);
    }

    bool placed_All_Mats()
    {
        if(b_Wood >= max_Wood && b_Stone >= max_Stone)
        {
            return true;
        }

        return false;
    }

    void built_Wood()
    {
        b_Wood++;
    }

    void built_Stone()
    {
        b_Stone++;
    }

    /// <summary>
    /// Checks to see if the storage have any materials in it.
    /// </summary>
    /// <returns>True = has material, False = has no material.</returns>
    public bool has_Mat()
    {
        if(transform.FindChild("Storage").childCount > 0)
        {
            return true;
        }

        return false;
    }

    void add_Wood(int amount)
    {
        c_Wood += amount;

        if(c_Wood >= max_Wood)
        {
            c_Wood = max_Wood;
        }
    }

    void add_Stone(int amount)
    {
        c_Stone += amount;
        
        if(c_Stone >= max_Stone)
        {
            c_Stone = max_Stone;
        }
    }

    public void add_Mat(string name, int amount)
    {
        if(name == "Wood")
        {
            add_Wood(amount);
        }
        else if(name == "Stone")
        {
            add_Stone(amount);
        }
    }

    public bool is_Mat_Req()
    {
        if(c_Wood >= max_Wood && c_Stone >= max_Stone)
        {
            return false;
        }

        return true;
    }

    /// <summary>
    /// Checks to see if wood is required.
    /// </summary>
    /// <returns>True = it is required. False = it is not required.</returns>
    public bool is_Wood_Req()
    {
        if(c_Wood >= max_Wood)
        {
            return false;
        }

        return true;
    }

    /// <summary>
    /// Returns number of wood required.
    /// </summary>
    /// <returns>int (max_Wood - c_Wood)</returns>
    public int get_Num_Wood_Req()
    {
        return (max_Wood - c_Wood);
    }

    public bool is_Stone_Req()
    {
        if(c_Stone >= max_Stone)
        {
            return false;
        }

        return true;
    }

    public int get_Num_Stone_Req()
    {
        return (max_Stone - c_Stone);
    }

    public void use_Material()
    {
        if (transform.FindChild("Storage").GetChild(0).GetComponent<Produce_Info>().name == "Wood")
        {
            built_Wood();
            Destroy(transform.FindChild("Storage").GetChild(0).gameObject);
        }else if (transform.FindChild("Storage").GetChild(0).GetComponent<Produce_Info>().name == "Stone")
        {
            built_Stone();
            Destroy(transform.FindChild("Storage").GetChild(0).gameObject);
        }
    }
}
