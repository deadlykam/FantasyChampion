﻿using UnityEngine;
using System.Collections;

public class Range : MonoBehaviour {

    public string collided_Object = "";

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerEnter(Collider other) {
        collided_Object = other.tag;

        //Debug.Log("other name: " + collided_Object);
    }

    void OnTriggerExit(Collider other)
    {
        collided_Object = "";

        //Debug.Log("other name: " + collided_Object);
    }
}
