﻿using UnityEngine;
using System.Collections;

public class Building_Info : MonoBehaviour {

    public enum BUILDING_TYPE { NONE, LUMBERCAMP, STONEMASONRY, HOME, STORAGE, TRANSPORT, UNIVERSITY, 
                                BLACKSMITH, BLACKSMITH_HAMMER, BLACKSMITH_AXE, BLACKSMITH_PICKAXE, BLACKSMITH_BAGPACK, 
                                WHEAT_FARM,
                                BAKERY
                              };
    public enum MATERIAL_TYPE { NONE, PRODUCTION, TREE, STONE, FARMING };

    public string name;
    public GameObject storage;
    public BUILDING_TYPE building_Type = BUILDING_TYPE.NONE;
    public MATERIAL_TYPE material_Type = MATERIAL_TYPE.NONE;
    public int max_Spots;
    public int free_Spots;
    public int storage_Limit;
    public bool active = false;
    public bool enable = true;

    //Variables for Transporter
    public bool isTransporting = false;

    private GameObject target_Material;
    
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (material_Type != MATERIAL_TYPE.PRODUCTION)
        {
            check_Target_Material_Alive();
        }
	}

    void check_Target_Material_Alive()
    {
        if (target_Material != null)
        {
            if (!target_Material.GetComponent<Material_Info>().alive)
            {
                Destroy(target_Material);
            }
        }
    }

    void checkActive()
    {
        if(free_Spots > 0)
        {
            active = true;
        }
        else
        {
            active = false;
        }
    }

    /// <summary>
    /// For buildings that produces products.
    /// </summary>
    /// <param name="index">Indicates which product to make</param>
    public void produce(int index)
    {
        if (!isLimit())
        {
            Production_Control pc = GetComponent<Production_Control>();

            GameObject temp = (GameObject)Instantiate(pc.produce[index], transform.FindChild("Produce").position, transform.FindChild("Produce").rotation);
            temp.name = pc.produce[index].GetComponent<Weapon_Info>().name;
            temp.transform.parent = storage.transform;
        }
    }

    /// <summary>
    /// Checks if the storage is full or not.
    /// </summary>
    /// <returns>
    ///     True = storage is full.
    ///     False = storage is not full.
    /// </returns>
    public bool isLimit()
    {
        if(storage.transform.childCount < storage_Limit)
        {
            return false;
        }

        return true;
    }

    public GameObject get_TargetMaterial()
    {
        return target_Material;
    }

    public void set_TargetMaterial(GameObject material)
    {
        target_Material = material;
    }

    public void remove_Spot()
    {
        free_Spots--;
        checkActive();
    }

    public void take_Spot()
    {
        free_Spots++;
        checkActive();
    }
    
    public bool isFree() {
        if(free_Spots != max_Spots)
        {
            return true;
        }

        return false;
    }
}
