﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Keeps the name of the produce.
/// </summary>
public class Produce_Info : MonoBehaviour {

    public string name;
}
