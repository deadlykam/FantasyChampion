﻿using UnityEngine;
using System.Collections;

public class Artifact_Controller : MonoBehaviour {

    public float health_Buff;
    public float health_Timer;
    public float stamina_Buff;
    public float stamina_Timer;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Player_Info pi = other.transform.gameObject.GetComponent<Player_Info>();

            if (pi.GetHealthTimer() <= 0)
            {
                pi.SetHealthBuff(health_Timer, health_Buff);
            }

            if (pi.GetStaminaTimer() <= 0)
            {
                pi.SetStaminaBuff(stamina_Timer, stamina_Buff);
            }
        }
    }
}
