﻿using UnityEngine;
using System.Collections;

public class Storage_Info : MonoBehaviour {

    //Materials
    public int wood;
    public int stone;

    //Items
    public int axe;
    public int pickAxe;
    public int carry;
    public int hammer;
    
    public void add_Items(string name)
    {
        if(name == "Wood")
        {
            wood++;
        }
        else if(name == "Stone")
        {
            stone++;
        }
        else if (name == "Axe")
        {
            axe++;
        }
        else if (name == "PickAxe")
        {
            pickAxe++;
        }
        else if (name == "Carry")
        {
            carry++;
        }
        else if (name == "Hammer")
        {
            hammer++;
        }
    }

    public int get_Item_Info(string name)
    {
        if (name == "Wood")
        {
            return wood;
        }
        else if (name == "Stone")
        {
            return stone;
        }
        else if (name == "Axe")
        {
            return axe;
        }
        else if (name == "PickAxe")
        {
            return pickAxe;
        }
        else if (name == "Carry")
        {
            return carry;
        }
        else if (name == "Hammer")
        {
            return hammer;
        }

        return 0;
    }
}
