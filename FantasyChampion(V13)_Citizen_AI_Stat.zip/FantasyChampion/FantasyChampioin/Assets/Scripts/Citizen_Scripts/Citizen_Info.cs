﻿using UnityEngine;
using System.Collections;

public class Citizen_Info : MonoBehaviour {

    public enum JOB_TYPE { NONE, LUMBERJACK, STONECUTTER, BUILDER, TRANSPORTER, ENGINEER
                           , TOOLMAKER, TOOLMAKER_HAMMER, TOOLMAKER_AXE, TOOLMAKER_PICKAXE, TOOLMAKER_BAGPACK, 
                           FARMER_WHEAT, BAKER
                         };

    public string name;
    public float health_Max = 100;
    public float health_Current = 100;
    public JOB_TYPE job_Type = JOB_TYPE.NONE;
    public bool is_In_Action = false;

    //Mode fields
    public float energy;
    public float hunger;
    public float entertainment;
    public float rate_Energy;
    public float rate_Hunger;
    public float rate_Entertainment;
    
	
	// Update is called once per frame
	void Update () {
        lowerStats();
	}

    /// <summary>
    /// Lowers all the stats according to their rate.
    /// </summary>
    void lowerStats()
    {
        if (energy > 0) {
            energy -= rate_Energy * Time.deltaTime;
        }
        else if(energy < 0)
        {
            energy = 0;
        }

        if (hunger > 0) {
            hunger -= rate_Hunger * Time.deltaTime;
        }
        else if (hunger < 0)
        {
            hunger = 0;
        }

        if (entertainment > 0) {
            entertainment -= rate_Entertainment * Time.deltaTime;
        }
        else if (entertainment < 0)
        {
            entertainment = 0;
        }
    }

    /// <summary>
    /// External conditions reduces the stats
    /// </summary>
    /// <param name="amount_Energy">Energy reduction rate</param>
    /// <param name="amount_Hunger">Hunger reduction rate</param>
    /// <param name="amount_Entertainment">Entertainment reduction rate</param>
    public void lowerStats(float amount_Energy, float amount_Hunger, float amount_Entertainment)
    {
        energy -= amount_Energy * Time.deltaTime;
        hunger -= amount_Hunger * Time.deltaTime;
        entertainment -= amount_Entertainment * Time.deltaTime;
    }

    /// <summary>
    /// Checks to see if the energy is low.
    /// </summary>
    /// <returns>True = energy is low, False = energy is not low</returns>
    public bool lowestEnergy()
    {
        if(energy < 20)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Checks to see if the hunger is low.
    /// </summary>
    /// <returns>True = energy is low, False = energy is not low</returns>
    public bool lowestHunger()
    {
        if (hunger < 20)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Checks to see if the entertainment is low.
    /// </summary>
    /// <returns>True = energy is low, False = energy is not low</returns>
    public bool lowestEntertainment()
    {
        if (entertainment < 20)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Increases energy over time.
    /// </summary>
    /// <param name="amount">The rate at which energy will increase</param>
    public void replenish_Energy(float amount)
    {
        if (energy < 100)
        {
            energy += amount * Time.deltaTime;
        }

        if (energy > 100)
        {
            energy = 100;
        }
    }

    /// <summary>
    /// Increases hunger.
    /// </summary>
    /// <param name="amount">The amount at which hunger increases</param>
    public void replenish_Hunger(float amount)
    {
        if (hunger < 100)
        {
            hunger += amount;
        }

        if(hunger > 100)
        {
            hunger = 100;
        }
    }

    /// <summary>
    /// Increases entertainment.
    /// </summary>
    /// <param name="amount">The amount at which entertainment increases</param>
    public void replenish_Entertainment(float amount)
    {
        if (entertainment < 100)
        {
            entertainment += amount;
        }

        if (entertainment > 100)
        {
            entertainment = 100;
        }
    }

    public bool is_Energy_OK()
    {
        if(energy >= 95)
        {
            return true;
        }

        return false;
    }

    public bool is_Hunger_OK()
    {
        if (hunger >= 95)
        {
            return true;
        }

        return false;
    }

    public bool is_Entertainment_OK()
    {
        if (entertainment >= 95)
        {
            return true;
        }

        return false;
    }
}
