﻿using UnityEngine;
using System.Collections;

public class Citizen_AI : MonoBehaviour {

    public enum State { IDLE,
                        MOVE_RAN, MOVE_PLAYER, MOVE_BUILDING, MOVE_BLACKSMITH, MOVE_WORK_BUILDING, MOVE_WEAPON_BUILDING, MOVE_PLACED_BUILDING, MOVE_TARGET_STORAGE_PB, MOVE_TARGET_STORAGE_P,
                        MOVE_PRODUCTION_BUILDING, MOVE_STORAGE, MOVE_HOME, MOVE_FOOD_BUILDING, 
                        SEARCH_WEAPON, PICK_UP_MAT, SEARCH_TARGET_STORAGE_STORAGE, PLANTING, HARVEST, SEARCH_TARGET_MATERIAL, SEARCH_FOOD, 
                        SEARCH_TARGET_BUILDING, SEARCH_TARGET_STORAGE, MOVE_TARGET_BUILDING, MOVE_TARGET_STORAGE, SEARCH_TARGET_STORAGE_PB, SEARCH_TARGET_STORAGE_P,
                        WORK };
    
    public GameObject home;
    public float distance = 0;
    public float distance_Interact = 0;

    private GameObject Buildings;
    private GameObject Player;

    public float timer_IDLE = 0;
    public State state = State.IDLE;

    private Animator anim;
    private Citizen_Info ci;
    private int visit_Count = -1;

    private GameObject LH;
    private GameObject RH;
    private GameObject Weapon;
    private GameObject Material;
    private GameObject Placed_Buildings;

    //Fields for stats
    private State pre_State = State.IDLE;
    private bool pre_Is_Action = false;
    private GameObject stat_GameObject;
    //Fields for work
    private GameObject work_Building;
    private GameObject target_Material;
    private GameObject weapon_Building;
    private bool isWeapon = false;
    //Fields for transporters
    private GameObject target_Building;
    private GameObject target_Storage;
    private int count_Target_Building = 0;
    private int count_Target_Storage = 0;

	// Use this for initialization
	void Start () {
        anim = GetComponentInChildren<Animator>();
        ci = GetComponent<Citizen_Info>();

        LH = transform.FindChild("Citizen_Armature").FindChild("Body").FindChild("Hand_L").gameObject;
        RH = transform.FindChild("Citizen_Armature").FindChild("Body").FindChild("Hand_R").gameObject;
        
        Player = transform.root.FindChild("Player").gameObject;
        Buildings = transform.root.FindChild("Buildings").gameObject;

        if (Buildings.transform.childCount == 0)
        {
            state = State.MOVE_PLAYER;
        }
	}
	
	// Update is called once per frame
	void Update () {
        if(work_Building != null && work_Building.GetComponent<Building_Info>().enable)
        {
            if (ci.job_Type == Citizen_Info.JOB_TYPE.TRANSPORTER)
            {
                AI_STATES_TRANSPORTER();
            }
            else if (ci.job_Type == Citizen_Info.JOB_TYPE.ENGINEER)
            {
                AI_STATES_ENGINEER();
            }
            else if (is_Production_AI() || is_Cook_AI())
            {
                AI_STATES_PRODUCTIONS();
            }
            else if (is_Farmer_AI())
            {
                AI_STATES_FARMERS();
            }
            else if (is_Gatherer_AI())
            {
                AI_STATES_GATHERER();
            }
        }
        else if(work_Building != null && !work_Building.GetComponent<Building_Info>().enable)
        {
            idle_Me();
        }
        else
        {
            AI_STATES_FREE_AI();
        }

        CHECK_STATS();
        STATE_FOR_STATS();
    }

    /// <summary>
    /// AI States for farmers only.
    /// </summary>
    void AI_STATES_FARMERS()
    {
        if(state == State.MOVE_WORK_BUILDING)
        {
            if(!MOVE(work_Building.transform.FindChild("Entrance").gameObject, true))
            {
                teleport_To_Action();
                state = State.WORK;
            }
        }
        else if (state == State.WORK)
        {
            if (work_Building.GetComponent<Production_Farmer>().is_All_Dead())
            {
                state = State.PLANTING;
            }
            else if (work_Building.GetComponent<Production_Farmer>().is_All_Grown())
            {
                state = State.HARVEST;
            }
        }
        else if(state == State.HARVEST)
        {
            if (!work_Building.GetComponent<Production_Farmer>().is_All_Dead())
            {
                if (target_Material == null)
                {
                    target_Material = work_Building.GetComponent<Production_Farmer>().get_Material_GO();
                    doWork(false);
                }
                else
                {
                    if(!MOVE(target_Material, false))
                    {
                        doWork(true);
                        if (Weapon.GetComponent<Weapon_Info>().collect_Mat)
                        {
                            state = State.MOVE_STORAGE;
                            Weapon.GetComponent<Weapon_Info>().collect_Mat = false;
                            doWork(false);
                        }
                    }
                }
            }
            else
            {
                state = State.WORK;
            }
        }
        else if (state == State.MOVE_STORAGE)
        {
            if (!MOVE(work_Building.GetComponent<Building_Info>().storage, true))
            {
                drop_Material();

                if (work_Building.GetComponent<Building_Info>().isLimit())
                {
                    pick_Up_Material();
                    state = State.SEARCH_TARGET_STORAGE;
                }
                else
                {
                    state = State.HARVEST;
                }
            }
        }
        else if(state == State.SEARCH_TARGET_STORAGE)
        {
            if (search_target_storage())
            {
                state = State.MOVE_TARGET_STORAGE;
                teleport_To_Entrance();
            }
        }
        else if(state == State.MOVE_TARGET_STORAGE)
        {
            if(!MOVE(target_Storage, true))
            {
                drop_Produce();
                state = State.MOVE_WORK_BUILDING;
            }
        }
        else if(state == State.PLANTING)
        {
            if (work_Building.GetComponent<Production_Farmer>().is_All_Planted())
            {
                state = State.WORK;
            }
            else
            {
                if(!MOVE(work_Building.GetComponent<Production_Farmer>().get_Cur_Plant_Pos(), false))
                {
                    plant_Seed();
                    work_Building.GetComponent<Production_Farmer>().next_Spot();
                }
            }
        }
        else
        {
            STATE_FOR_SEARCHING_WEAPON(ci.job_Type);
        }
    }

    /// <summary>
    /// AI States for Gatherer only like lumberjack, stonemasonry etc.
    /// </summary>
    void AI_STATES_GATHERER()
    {
        if (state == State.MOVE_WORK_BUILDING)
        {
            if (!MOVE(work_Building.transform.FindChild("Entrance").gameObject, false))
            {
                drop_Material();
                state = State.WORK;
            }
        }
        else if (state == State.WORK)
        {
            if (target_Material == null)
            {
                target_Material = work_Building.GetComponent<Building_Info>().get_TargetMaterial();
                anim.SetBool("walk", false);
                anim.SetBool("idle", true);
            }
            else
            {
                if (!MOVE(target_Material.gameObject, false))
                {
                    if (!work_Building.GetComponent<Building_Info>().isLimit())
                    {
                        doWork(true);
                        
                        if (Weapon.GetComponent<Weapon_Info>().collect_Mat)
                        {
                            state = State.MOVE_WORK_BUILDING;
                            Weapon.GetComponent<Weapon_Info>().collect_Mat = false;
                            doWork(false);
                        }

                        if (!is_Target_Material_Alive())
                        {
                            doWork(false);
                            state = State.MOVE_WORK_BUILDING;
                        }
                    }
                    else
                    {
                        state = State.PICK_UP_MAT;
                        doWork(false);
                    }
                }
                else
                {
                    doWork(false);
                }
            }
        }
        else if (state == State.PICK_UP_MAT)
        {
            if (!MOVE(work_Building, true))
            {
                if (work_Building.GetComponent<Building_Info>().isLimit())
                {
                    pick_Up_Material();
                    state = State.SEARCH_TARGET_STORAGE;
                }
                else
                {
                    state = State.WORK;
                }
            }
        }
        else if (state == State.SEARCH_TARGET_STORAGE)
        {
            if (search_target_storage())
            {
                state = State.MOVE_TARGET_STORAGE;
            }
        }
        else if (state == State.MOVE_TARGET_STORAGE)
        {
            if (!MOVE(target_Storage, true))
            {
                if (drop_Produce())
                {
                    state = State.WORK;
                }
            }
        }
        else
        {
            STATE_FOR_SEARCHING_WEAPON(ci.job_Type);
        }
    }

    /// <summary>
    /// AI states for production citizen only.
    /// </summary>
    void AI_STATES_PRODUCTIONS()
    {
        if (state == State.MOVE_WORK_BUILDING)
        {
            if(!MOVE(work_Building, true))
            {
                teleport_To_Action();
                state = State.WORK;
            }
        }
        else if(state == State.WORK)
        {
            if (!has_Weapon_Produce() && Weapon.GetComponent<Weapon_Info>().Mat != null)
            {
                drop_Produce_Production_2();

                if (work_Building.GetComponent<Production>().is_Mat_Req())
                {
                    state = State.SEARCH_TARGET_STORAGE;
                }
            }
            else if (work_Building.GetComponent<Production>().has_Mat())
            {
                doWork(true);
            }
            else
            {
                if (work_Building.GetComponent<Production>().has_Produce())
                {
                    pick_Up_Material();
                    work_Building.GetComponent<Production>().reset_Current();
                    state = State.SEARCH_TARGET_STORAGE_STORAGE;
                }
                else
                {
                    state = State.SEARCH_TARGET_STORAGE;
                }

                doWork(false);
            }
        }
        else if(state == State.SEARCH_TARGET_STORAGE_STORAGE)
        {
            if (search_target_storage())
            {
                state = State.MOVE_TARGET_STORAGE;
                teleport_To_Entrance();
            }
        }
        else if(state == State.SEARCH_TARGET_STORAGE)
        {
            if (search_Target_Storage_Produce_2(false))
            {
                if (ci.is_In_Action)
                {
                    teleport_To_Entrance();
                }

                state = State.MOVE_TARGET_STORAGE;
            }
        }
        else if(state == State.MOVE_TARGET_STORAGE)
        {
            if (!MOVE(target_Storage.transform.FindChild("Storage").gameObject, true))
            {
                if (has_Weapon_Produce())
                {
                    drop_Produce();
                }

                if (pick_Up_Produce_Production())
                {
                    state = State.MOVE_WORK_BUILDING;
                }
                else
                {
                    state = State.SEARCH_TARGET_STORAGE;
                }
            }
        }
        else
        {
            STATE_FOR_SEARCHING_WEAPON(ci.job_Type);
        }
    }

    /// <summary>
    /// AI states for engineer only
    /// </summary>
    void AI_STATES_ENGINEER()
    {
        if(state == State.SEARCH_TARGET_BUILDING)
        {
            if (search_Placed_Buildings())
            {
                state = State.SEARCH_TARGET_STORAGE;
            }
        }
        else if (state == State.SEARCH_TARGET_STORAGE)
        {
            if (is_Target_Building_Destroyed())
            {
                state = State.SEARCH_TARGET_BUILDING;
            }
            else if (search_Target_Storage_Produce_2(true))
            {
                state = State.MOVE_TARGET_STORAGE;
            }
        }
        else if(state == State.MOVE_TARGET_STORAGE)
        {
            if (!MOVE(target_Storage, true))
            {
                if (is_Target_Building_Destroyed())
                {
                    state = State.SEARCH_TARGET_BUILDING;
                }
                else if (pick_Up_Produce_For_PlacedBuilding())
                {
                    state = State.MOVE_TARGET_BUILDING;
                }
                else
                {
                    state = State.SEARCH_TARGET_STORAGE;
                }
            }
        }
        else if(state == State.MOVE_TARGET_BUILDING)
        {
            if (!is_Target_Building_Destroyed())
            {
                if (!MOVE(target_Building, true))
                {
                    if (has_Weapon_Mat()) {
                        drop_Produce_PB();
                    }
                    else if (target_Building.GetComponent<Material_Required>().has_Mat())
                    {
                        doWork(true);
                    }
                    else
                    {
                        doWork(false);
                        state = State.MOVE_TARGET_STORAGE;
                    }
                }
                else
                {
                    doWork(false);
                }
            }
            else
            {
                doWork(false);
                teleport_To_Entrance_PB();
                state = State.SEARCH_TARGET_BUILDING;
            }
        }
        else
        {
            STATE_FOR_SEARCHING_WEAPON(ci.job_Type);
        }
    }

    /// <summary>
    /// AI states for transporter only. Depricated will not need it later.
    /// </summary>
    void AI_STATES_TRANSPORTER()
    {
        if (state == State.SEARCH_TARGET_BUILDING)
        {
            if (search_Placed_Buildings_InProgress())
            {
                state = State.SEARCH_TARGET_STORAGE_PB;
            }
            else if (search_Target_Building_Need_Produce())
            {
                state = State.SEARCH_TARGET_STORAGE_P;
            }
            else if (search_target_building())
            {
                state = State.MOVE_TARGET_BUILDING;
            }
            
            increment_Count_Target_Building();
        }
        else if (state == State.SEARCH_TARGET_STORAGE)
        {
            if (search_target_storage())
            {
                state = State.MOVE_TARGET_STORAGE;
            }
        }
        else if(state == State.SEARCH_TARGET_STORAGE_P)
        {
            if (search_Target_Storage_Produce(false))
            {
                state = State.MOVE_TARGET_STORAGE_P;
            }
        }
        else if (state == State.SEARCH_TARGET_STORAGE_PB)
        {
            if (is_Target_Building_Destroyed())
            {
                state = State.SEARCH_TARGET_BUILDING;
            }
            else if (search_Target_Storage_Produce(true))
            {
                state = State.MOVE_TARGET_STORAGE_PB;
            }
        }
        else if(state == State.MOVE_TARGET_STORAGE_P)
        {
            if (!MOVE(target_Storage, true)) 
            {
                if (pick_Up_Produce_For_Production())
                {
                    state = State.MOVE_PRODUCTION_BUILDING;
                }
                else
                {
                    state = State.SEARCH_TARGET_STORAGE_P;
                }
            }
        }
        else if (state == State.MOVE_TARGET_STORAGE_PB)
        {
            if(!MOVE(target_Storage, true))
            {
                if (is_Target_Building_Destroyed())
                {
                    state = State.SEARCH_TARGET_BUILDING;
                }
                else if (pick_Up_Produce_For_PlacedBuilding())
                {
                    state = State.MOVE_PLACED_BUILDING;
                }
                else
                {
                    state = State.SEARCH_TARGET_STORAGE_PB;
                }
            }
        }
        else if (state == State.MOVE_PLACED_BUILDING)
        {
            if(!MOVE(target_Building, true))
            {
                drop_Produce_PB();

                if (target_Building != null)
                {
                    state = State.MOVE_TARGET_STORAGE_PB;
                }
                else
                {
                    state = State.SEARCH_TARGET_BUILDING;
                }
            }
        }
        else if(state == State.MOVE_PRODUCTION_BUILDING)
        {
            if(!MOVE(target_Building, true))
            {
                drop_Produce_Production();

                if (target_Building.GetComponent<Production>().is_Mat_Req())
                {
                    state = State.MOVE_TARGET_STORAGE_P;
                }
                else
                {
                    target_Building.GetComponent<Building_Info>().isTransporting = false;
                    state = State.SEARCH_TARGET_BUILDING;
                }
            }
        }
        else if (state == State.MOVE_TARGET_BUILDING)
        {
            if (!MOVE(target_Building, false))
            {
                pick_Up_Produce();
                state = State.SEARCH_TARGET_STORAGE;
            }
            else
            {
                if (is_Target_Building_Empty())
                {
                    state = State.SEARCH_TARGET_BUILDING;
                    target_Building.GetComponent<Building_Info>().isTransporting = false;
                }
            }
        }
        else if (state == State.MOVE_TARGET_STORAGE)
        {
            if (!MOVE(target_Storage, true))
            {
                if (drop_Produce())
                {
                    state = State.SEARCH_TARGET_BUILDING;
                }
            }
        }
        else
        {
            STATE_FOR_SEARCHING_WEAPON(ci.job_Type);
        }
    }

    /// <summary>
    /// Basic states for all AI.
    /// </summary>
    void AI_STATES_FREE_AI() {
        if (state == State.IDLE)
        {
            anim.SetBool("idle", true);
            anim.SetBool("walk", false);

            if (visit_Count != Buildings.transform.childCount - 1)
            {
                increase_Visit_Count();
                state = State.MOVE_BUILDING;
            }
        }
        else if (state == State.MOVE_PLAYER)
        {
            MOVE(Player, true);

            if (Buildings.transform.childCount > 0)
            {
                increase_Visit_Count();
                state = State.MOVE_BUILDING;
            }
        }
        else if (state == State.MOVE_BUILDING)
        {
            if(!MOVE(Buildings.transform.GetChild(visit_Count).transform.FindChild("Entrance").gameObject, false))
            {
                if (Check_Jobs())
                {
                    if (GetComponent<Citizen_Info>().job_Type != Citizen_Info.JOB_TYPE.TOOLMAKER)
                    {
                        state = State.SEARCH_WEAPON;
                    }
                    else
                    {
                        state = State.WORK;
                    }

                    //weapon_Building = Buildings.transform.FindChild("Blacksmith").gameObject; //<--- Change this later to find the neareast tool.
                }
                else
                {
                    state = State.IDLE;
                }
            }
        }

        //Debug.Log("State = " + state);
        //Debug.Log("Buildings Count: " + Buildings.transform.childCount + ", Visit_Count: " + visit_Count);
    }

    /// <summary>
    /// Checks the stats and takes action according to that.
    /// </summary>
    void CHECK_STATS()
    {
        if (ci.lowestEnergy() && state != State.SEARCH_FOOD && state != State.MOVE_FOOD_BUILDING)
        {
            // TODO: Other means of replenishing energy.
            if (state != State.MOVE_HOME)
            {
                pre_State = state;
                pre_Is_Action = ci.is_In_Action;

                state = State.MOVE_HOME;

                if (ci.is_In_Action)
                {
                    teleport_To_Entrance();
                }

                idle_Me();
            }
        }
        else if (ci.lowestHunger() && state != State.MOVE_HOME)
        {
            //TODO: Replenish hunger.
            if (state != State.SEARCH_FOOD && state != State.MOVE_FOOD_BUILDING)
            {
                pre_State = state;
                pre_Is_Action = ci.is_In_Action;

                state = State.SEARCH_FOOD;

                if (ci.is_In_Action)
                {
                    teleport_To_Entrance();
                }

                idle_Me();
            }
        }
        else if (ci.lowestEntertainment())
        {
            //TODO: Replenish entertainment.
        }
    }

    /// <summary>
    /// These states are determined by the stats of the AI.
    /// </summary>
    void STATE_FOR_STATS()
    {
        if(state == State.MOVE_HOME)
        {
            if(!MOVE(home.transform.FindChild("Entrance").gameObject, false))
            {
                if (ci.is_Energy_OK())
                {
                    if (!pre_Is_Action)
                    {
                        state = pre_State;
                    }
                    else
                    {
                        state = State.MOVE_WORK_BUILDING;
                    }
                }
                else
                {
                    ci.replenish_Energy(25);
                }
            }
        }
        else if(state == State.SEARCH_FOOD)
        {
            if (search_Food())
            {
                state = State.MOVE_FOOD_BUILDING;
            }
        }
        else if(state == State.MOVE_FOOD_BUILDING)
        {
            if (!MOVE(stat_GameObject.transform.FindChild("Storage").gameObject, true))
            {
                if (eat_Food())
                {
                    if (ci.is_Hunger_OK())
                    {
                        if (!pre_Is_Action)
                        {
                            state = pre_State;
                        }
                        else
                        {
                            state = State.MOVE_WORK_BUILDING;
                        }
                    }
                }
                else
                {
                    state = State.SEARCH_FOOD;
                }
            }
        }
    }

    /// <summary>
    /// Combined two states that is required by all Citizen_AI.
    /// (STATE.SEARCH_WEAPON, STATE.MOVE_WEAPON_BUILDING)
    /// </summary>
    void STATE_FOR_SEARCHING_WEAPON(Citizen_Info.JOB_TYPE job_Type)
    {
        if (state == State.SEARCH_WEAPON)
        {
            if (is_Weapon_Building(getWeapon_Name()))
            {
                state = State.MOVE_WEAPON_BUILDING;
            }
        }
        else if (state == State.MOVE_WEAPON_BUILDING)
        {
            if (!MOVE(weapon_Building.transform.FindChild("Entrance").gameObject, false))
            {
                if (!isWeapon)
                {
                    if (!getWeapon())
                    {
                        state = State.SEARCH_WEAPON;
                    }
                }
                else
                {
                    if(job_Type == Citizen_Info.JOB_TYPE.TRANSPORTER || job_Type == Citizen_Info.JOB_TYPE.ENGINEER)
                    {
                        state = State.SEARCH_TARGET_BUILDING;
                    }
                    else if (is_Production_AI() || is_Farmer_AI())
                    {
                        state = State.MOVE_WORK_BUILDING;
                    }
                    else
                    {
                        state = State.WORK;
                    }
                }
            }
        }
    }

    /// <summary>
    /// Finds the first building with the required item.
    /// </summary>
    /// <param name="item_Name">Search this item</param>
    /// <returns>True = found the item. False = did not find the item.</returns>
    bool is_Weapon_Building(string item_Name)
    {
        for(int i = 0; i < Buildings.transform.GetChildCount(); i++)
        {
            /*
            if (Buildings.transform.GetChild(i).name == "Blacksmith")
            {
                if(Buildings.transform.GetChild(i).FindChild("Storage").FindChild(item_Name) != null)
                {
                    weapon_Building = Buildings.transform.GetChild(i).gameObject;
                    return true;
                }
            }
            else if (Buildings.transform.GetChild(i).name == "Storage")
            {
                if (Buildings.transform.GetChild(i).FindChild("Storage").FindChild(item_Name) != null)
                {
                    weapon_Building = Buildings.transform.GetChild(i).gameObject;
                    return true;
                }
            }
            */ //<---Version 1

            /*if (Buildings.transform.GetChild(i).name == "Storage")
            {
                if (Buildings.transform.GetChild(i).FindChild("Storage").FindChild(item_Name) != null)
                {
                    weapon_Building = Buildings.transform.GetChild(i).gameObject;
                    return true;
                }
            }*/ //Version 2

            if(Buildings.transform.GetChild(i).FindChild("Storage") != null)
            {
                if (Buildings.transform.GetChild(i).FindChild("Storage").FindChild(item_Name) != null)
                {
                    weapon_Building = Buildings.transform.GetChild(i).gameObject;
                    return true;
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Returns the Weapon name the character will use.
    /// </summary>
    /// <returns>Weapon Name</returns>
    string getWeapon_Name()
    {
        if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.LUMBERJACK)
        {
            return "Axe";
        }
        else if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.STONECUTTER)
        {
            return "Pickaxe";
        }
        else if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.TRANSPORTER)
        {
            return "Carry";
        }
        else if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.ENGINEER || is_Production_AI())
        {
            return "Hammer";
        }
        else if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.FARMER_WHEAT)
        {
            return "Sickle";
        }
        else if (is_Cook_AI())
        {
            return "Spatula";
        }

        return "";
    }

    /// <summary>
    /// Get weapon from the blacksmith.
    /// Will later try to make this method more dynamic by using the "string getWeapon_Name()" method. Need to fix
    /// the scale issue first.
    /// <returns>True = Weapon found. False = Weapon not found.</returns>
    /// </summary>
    bool getWeapon()
    {
        if(GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.LUMBERJACK)
        {
            if(weapon_Building.transform.FindChild("Storage").FindChild("Axe") != null)
            {
                Weapon = weapon_Building.transform.FindChild("Storage").FindChild("Axe").gameObject;

                Weapon.GetComponent<Rigidbody>().isKinematic = true;
                Weapon.GetComponent<BoxCollider>().isTrigger = true;
                Weapon.transform.parent = RH.transform;

                Weapon.transform.localPosition = new Vector3(0, 0, 0);
                Weapon.transform.localRotation = Quaternion.Euler(180, 0, 0);
                Weapon.transform.localScale = new Vector3(1, 1, 1);
                isWeapon = true;
                return true;
            }
        }
        else if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.STONECUTTER)
        {
            if (weapon_Building.transform.FindChild("Storage").FindChild("Pickaxe") != null)
            {
                Weapon = weapon_Building.transform.FindChild("Storage").FindChild("Pickaxe").gameObject;

                Weapon.GetComponent<Rigidbody>().isKinematic = true;
                Weapon.GetComponent<BoxCollider>().isTrigger = true;
                Weapon.transform.parent = RH.transform;

                Weapon.transform.localPosition = new Vector3(0, 0, 0);
                Weapon.transform.localRotation = Quaternion.Euler(180, 90, 0);
                Weapon.transform.localScale = new Vector3(1, 1, 1);
                isWeapon = true;
                return true;
            }
        }
        else if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.TRANSPORTER)
        {
            if (weapon_Building.transform.FindChild("Storage").FindChild("Carry") != null)
            {
                Weapon = weapon_Building.transform.FindChild("Storage").FindChild("Carry").gameObject;

                Weapon.GetComponent<Rigidbody>().isKinematic = true;
                Weapon.GetComponent<BoxCollider>().isTrigger = true;
                Weapon.transform.parent = RH.transform;

                Weapon.transform.localPosition = new Vector3(0, 0, 0);
                Weapon.transform.localRotation = Quaternion.Euler(180, 0, 0);
                Weapon.transform.localScale = new Vector3(.05f, 2, 0.05f);
                isWeapon = true;
                return true;
            }
        }
        else if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.ENGINEER || is_Production_AI())
        {
            if (weapon_Building.transform.FindChild("Storage").FindChild("Hammer") != null)
            {
                Weapon = weapon_Building.transform.FindChild("Storage").FindChild("Hammer").gameObject;

                Weapon.GetComponent<Rigidbody>().isKinematic = true;
                Weapon.GetComponent<BoxCollider>().isTrigger = true;
                Weapon.transform.parent = RH.transform;

                Weapon.transform.localPosition = new Vector3(0, 0, 0);
                Weapon.transform.localRotation = Quaternion.Euler(180, 0, 0);
                Weapon.transform.localScale = new Vector3(1, 1, 1);
                isWeapon = true;
                return true;
            }
        }
        else if (is_Cook_AI())
        {
            if (weapon_Building.transform.FindChild("Storage").FindChild("Spatula") != null)
            {
                Weapon = weapon_Building.transform.FindChild("Storage").FindChild("Spatula").gameObject;

                Weapon.GetComponent<Rigidbody>().isKinematic = true;
                Weapon.GetComponent<BoxCollider>().isTrigger = true;
                Weapon.transform.parent = RH.transform;

                Weapon.transform.localPosition = new Vector3(0, 0, 0);
                Weapon.transform.localRotation = Quaternion.Euler(180, 0, 0);
                Weapon.transform.localScale = new Vector3(1, 1, 1);
                isWeapon = true;
                return true;
            }
        }
        else if (GetComponent<Citizen_Info>().job_Type == Citizen_Info.JOB_TYPE.FARMER_WHEAT)
        {
            if (weapon_Building.transform.FindChild("Storage").FindChild("Sickle") != null)
            {
                Weapon = weapon_Building.transform.FindChild("Storage").FindChild("Sickle").gameObject;

                Weapon.GetComponent<Rigidbody>().isKinematic = true;
                Weapon.GetComponent<BoxCollider>().isTrigger = true;
                Weapon.transform.parent = RH.transform;

                Weapon.transform.localPosition = new Vector3(0, 0, 0);
                Weapon.transform.localRotation = Quaternion.Euler(180, 180, 0);
                Weapon.transform.localScale = new Vector3(1, 1, 1);
                isWeapon = true;
                return true;
            }
        }

        return false;
    }

    //Check what work the citizen does.
    void doWork(bool enable)
    {
        if(ci.job_Type == Citizen_Info.JOB_TYPE.LUMBERJACK || is_Farmer_AI())
        {
            anim.SetBool("cut_tree", enable);
            collect_Material();
        }
        else if (ci.job_Type == Citizen_Info.JOB_TYPE.STONECUTTER)
        {
            anim.SetBool("cut_stone", enable);
            collect_Material();
        }
        else if(ci.job_Type == Citizen_Info.JOB_TYPE.ENGINEER)
        {
            anim.SetBool("cut_stone", enable);
            build_Building();
        }
        else if (is_Production_AI() || is_Cook_AI())
        {
            anim.SetBool("cut_stone", enable);
            build_Produce();
        }

        if (enable)
        {
            ci.lowerStats(1, .5f, .25f);
        }
    }

    /// <summary>
    /// Collects damages the target_Material and collects material from it.
    /// </summary>
    void collect_Material()
    {
        if (anim.GetBool("collect_Mat") && is_Target_Material_Alive())
        {
            target_Material.GetComponent<Material_Info>().health_Decrease(Weapon.GetComponent<Weapon_Info>().damage);
            Weapon.GetComponent<Weapon_Info>().add_Process();
            anim.SetBool("collect_Mat", false);

            if (Weapon.GetComponent<Weapon_Info>().collect_Mat)
            {
                Material = (GameObject)Instantiate(target_Material.GetComponent<Material_Info>().material, transform.position, transform.rotation);

                Material.GetComponent<Rigidbody>().isKinematic = true;
                Material.GetComponent<BoxCollider>().isTrigger = true;
                Material.transform.parent = LH.transform;

                Material.transform.localPosition = new Vector3(0, 0, 0);
                Material.transform.localRotation = Quaternion.Euler(90, 0, 90);

                /*state = State.MOVE_WORK_BUILDING;//<--- Move this out of the method. This may create confusion in future.

                Weapon.GetComponent<Weapon_Info>().collect_Mat = false;//<--- Move this out of the method. This may create confusion in future.

                doWork(false);//<--- Move this out of the method. This may create confusion in future.*/
            }
        }
    }

    /// <summary>
    /// Builds the Placed building which is target_Building.
    /// </summary>
    void build_Building()
    {
        if (anim.GetBool("collect_Mat"))
        {
            Weapon.GetComponent<Weapon_Info>().add_Process();
            anim.SetBool("collect_Mat", false);

            if (Weapon.GetComponent<Weapon_Info>().collect_Mat)
            {
                target_Building.GetComponent<Material_Required>().use_Material();
                Weapon.GetComponent<Weapon_Info>().collect_Mat = false;
            }
        }
    }

    /// <summary>
    /// Builds the Produce of the building.
    /// </summary>
    void build_Produce()
    {
        if (anim.GetBool("collect_Mat"))
        {
            Weapon.GetComponent<Weapon_Info>().add_Process();
            anim.SetBool("collect_Mat", false);

            if (Weapon.GetComponent<Weapon_Info>().collect_Mat)
            {
                work_Building.GetComponent<Production>().use_Material();
                Weapon.GetComponent<Weapon_Info>().collect_Mat = false;
            }
        }
    }

    /// <summary>
    /// This method moves the character towards the target position.
    /// </summary>
    /// <param name="target">Gameobject towards which the character will move.</param>
    /// <param name="isDistance">isDistance = true, will use distance param. isDistance = false, will use distance_Interact param</param>
    /// <remarks>Returns false if the character have stopped moving. True if it is still moving.</remarks>
    bool MOVE(GameObject target, bool isDistance)
    {
        if (isDistance)
        {
            if (Vector3.Distance(transform.position, target.transform.position) < distance)
            {
                anim.SetBool("walk", false);
                anim.SetBool("idle", true);

                return false;
            }
            else
            {
                Look_At_Target(target);
                anim.SetBool("walk", true);
                anim.SetBool("idle", false);
            }
        }
        else
        {
            if (Vector3.Distance(transform.position, target.transform.position) < distance_Interact)
            {
                anim.SetBool("walk", false);
                anim.SetBool("idle", true);

                return false;
            }
            else
            {
                Look_At_Target(target);
                anim.SetBool("walk", true);
                anim.SetBool("idle", false);
            }
        }

        return true;
    }

    /// <summary>
    /// Drops off the material at the work_building.
    /// </summary>
    void drop_Material()
    {
        GameObject temp_Mat = (GameObject)Instantiate(Material, work_Building.transform.FindChild("Produce").position, work_Building.transform.FindChild("Produce").rotation);
        Destroy(Material);

        temp_Mat.name = temp_Mat.GetComponent<Produce_Info>().name;
        temp_Mat.transform.parent = work_Building.GetComponent<Building_Info>().storage.transform;
        //temp_Mat.transform.localPosition = new Vector3(0, 0, 0);
        temp_Mat.transform.localScale = temp_Mat.transform.localScale * 50;

        temp_Mat.GetComponent<Rigidbody>().isKinematic = false;
        temp_Mat.GetComponent<BoxCollider>().isTrigger = false;
    }

    /// <summary>
    /// Checks if the target_Material is null or not. If it is null then target_Material is dead, if it is not null then target_Material is alive.
    /// </summary>
    /// <returns>true if target_Material is alive. false if target_Material is dead</returns>
    bool is_Target_Material_Alive()
    {
        if(target_Material == null)
        {
            return false;
        }

        return true;
    }

    //Check to see fo jobs are available.
    bool Check_Jobs()
    {
        Building_Info bi = Buildings.transform.GetChild(visit_Count).gameObject.GetComponent<Building_Info>();

        if (bi.isFree())
        {
            bi.take_Spot();

            work_Building = Buildings.transform.GetChild(visit_Count).gameObject;

            if (bi.building_Type == Building_Info.BUILDING_TYPE.LUMBERCAMP)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.LUMBERJACK;
            }
            else if (bi.building_Type == Building_Info.BUILDING_TYPE.STONEMASONRY)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.STONECUTTER;
            }
            else if(bi.building_Type == Building_Info.BUILDING_TYPE.BLACKSMITH)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.TOOLMAKER;
                teleport_To_Action();
            }
            else if (bi.building_Type == Building_Info.BUILDING_TYPE.BLACKSMITH_HAMMER)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.TOOLMAKER_HAMMER;
            }
            else if (bi.building_Type == Building_Info.BUILDING_TYPE.BLACKSMITH_AXE)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.TOOLMAKER_AXE;
            }
            else if (bi.building_Type == Building_Info.BUILDING_TYPE.BLACKSMITH_PICKAXE)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.TOOLMAKER_PICKAXE;
            }
            else if (bi.building_Type == Building_Info.BUILDING_TYPE.BLACKSMITH_BAGPACK)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.TOOLMAKER_BAGPACK;
            }
            else if(bi.building_Type == Building_Info.BUILDING_TYPE.WHEAT_FARM)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.FARMER_WHEAT;
            }
            else if (bi.building_Type == Building_Info.BUILDING_TYPE.BAKERY)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.BAKER;
            }
            else if (bi.building_Type == Building_Info.BUILDING_TYPE.TRANSPORT)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.TRANSPORTER;
                setup_Placed_Buildings();
            }
            else if (bi.building_Type == Building_Info.BUILDING_TYPE.UNIVERSITY)
            {
                ci.job_Type = Citizen_Info.JOB_TYPE.ENGINEER;
                setup_Placed_Buildings();
            }

            return true;
        }

        return false;
    }

    void setup_Placed_Buildings()
    {
        Placed_Buildings = Buildings.transform.parent.FindChild("Placed_Buildings").gameObject;
    }

    //====================CONDITIONS FOR ENGINEER ONLY=============================//

    /// <summary>
    /// Finds the first building to build
    /// </summary>
    /// <returns>True = found building, False = did not find</returns>
    bool search_Placed_Buildings()
    {
        if(Placed_Buildings.transform.childCount > 0)
        {
            for(int i = 0; i < Placed_Buildings.transform.childCount; i++)
            {
                if (!Placed_Buildings.transform.GetChild(i).GetComponent<Material_Required>().is_InProgress)
                {
                    target_Building = Placed_Buildings.transform.GetChild(i).gameObject;
                    target_Building.GetComponent<Material_Required>().is_InProgress = true;
                    target_Building.GetComponent<Material_Required>().take_Spot_Engineer();
                    return true;
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Checks to see if target building is null or not.
    /// </summary>
    /// <returns>True = null, False = Not null</returns>
    bool is_Target_Building_Destroyed()
    {
        if(target_Building == null)
        {
            return true;
        }

        return false;
    }

    //====================END======================================================//

    //====================CONDITIONS FOR TRANSPORTER ONLY==========================//

    /// <summary>
    /// Search for a Placed_Building which has an Engineer working on it.
    /// </summary>
    /// <returns>True = Found the building, False = Did not find it.</returns>
    bool search_Placed_Buildings_InProgress()
    {
        if (Placed_Buildings.transform.GetChildCount() > 0)
        {
            for (int i = 0; i < Placed_Buildings.transform.GetChildCount(); i++)
            {
                if (Placed_Buildings.transform.GetChild(i).GetComponent<Material_Required>().is_InProgress &&
                    Placed_Buildings.transform.GetChild(i).GetComponent<Material_Required>().isFree_Transporters())
                {
                    target_Building = Placed_Buildings.transform.GetChild(i).gameObject;
                    target_Building.GetComponent<Material_Required>().take_Spot_Transporter();
                    return true;
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Search for the building with some produce.
    /// </summary>
    /// <returns>
    /// True = found a building with produce.
    /// False = did not find any building with produce.
    /// </returns>
    bool search_target_building()
    {
        /*Debug.Log("childCount: " + Buildings.transform.childCount);
        Debug.Log("GetChildCount(): " + Buildings.transform.GetChildCount());
        Debug.Log("count_Target_Building: " + count_Target_Building);*/
        
        if (Buildings.transform.GetChild(count_Target_Building).GetComponent<Building_Info>().name != "Storage")
        {
            if (!Buildings.transform.GetChild(count_Target_Building).GetComponent<Building_Info>().isTransporting)
            {
                if (Buildings.transform.GetChild(count_Target_Building).FindChild("Storage") != null)
                {
                    if (check_Target_Building_Storage(Buildings.transform.GetChild(count_Target_Building).FindChild("Storage").gameObject))
                    {
                        if (Buildings.transform.GetChild(count_Target_Building).GetComponent<Production>() != null)
                        {
                            if (has_Produce(Buildings.transform.GetChild(count_Target_Building).FindChild("Storage").gameObject))
                            {
                                target_Building = Buildings.transform.GetChild(count_Target_Building).gameObject;
                                target_Building.GetComponent<Building_Info>().isTransporting = true;
                                return true;
                            }
                        }
                        else
                        {
                            target_Building = Buildings.transform.GetChild(count_Target_Building).gameObject;
                            target_Building.GetComponent<Building_Info>().isTransporting = true;
                            return true;
                        }
                    }
                }
            }
        }

        anim.SetBool("idle", true);
        anim.SetBool("walk", false);

        return false;
    }

    /// <summary>
    /// Searches for a building that needs some materials to make produce.
    /// </summary>
    /// <returns>True = found a building that needs produce, False = did not find any building that requires produce</returns>
    bool search_Target_Building_Need_Produce()
    {
        if(Buildings.transform.GetChild(count_Target_Building).GetComponent<Production>() != null)
        {
            if (!Buildings.transform.GetChild(count_Target_Building).GetComponent<Building_Info>().isTransporting)
            {
                if (Buildings.transform.GetChild(count_Target_Building).GetComponent<Production>().is_Mat_Req())
                {
                    target_Building = Buildings.transform.GetChild(count_Target_Building).gameObject;
                    target_Building.GetComponent<Building_Info>().isTransporting = true;
                    return true;
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Search for the first free space Storage.
    /// </summary>
    /// <returns>True = found a storage, False = did not find a storage.</returns>
    bool search_target_storage()
    {
        if (count_Target_Storage < Buildings.transform.childCount)
        {
            if (Buildings.transform.GetChild(count_Target_Storage).GetComponent<Building_Info>().name == "Storage")
            {
                Building_Info bi = Buildings.transform.GetChild(count_Target_Storage).GetComponent<Building_Info>();
                if (check_Target_Storage_Storage(Buildings.transform.GetChild(count_Target_Storage).FindChild("Storage").gameObject, bi.storage_Limit))
                {
                    target_Storage = Buildings.transform.GetChild(count_Target_Storage).gameObject;
                    return true;
                }
            }
            count_Target_Storage++;
        }
        else
        {
            count_Target_Storage = 0;
        }
        return false;
    }

    /// <summary>
    /// Search for a building which has some produce.
    /// </summary>
    /// <returns>True = has the produce, False = does not have it.</returns>
    bool search_Target_Storage_Produce(bool isPlacedBuild)
    {
        for(int i = 0; i < Buildings.transform.childCount; i++)
        {
            if (!Buildings.transform.GetChild(i).GetComponent<Building_Info>().isTransporting)
            {
                if (Buildings.transform.GetChild(i).FindChild("Storage") != null)
                {
                    if (check_Target_Building_Storage(Buildings.transform.GetChild(i).FindChild("Storage").gameObject))
                    {
                        if (isPlacedBuild)
                        {
                            if (!is_Target_Building_Destroyed())
                            {
                                Material_Required mr = target_Building.GetComponent<Material_Required>();

                                if (mr.is_Wood_Req())
                                {
                                    if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Wood"))
                                    {
                                        target_Storage = Buildings.transform.GetChild(i).gameObject;
                                        target_Storage.GetComponent<Building_Info>().isTransporting = true;
                                        return true;
                                    }
                                }
                                else if (mr.is_Stone_Req())
                                {
                                    if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Stone"))
                                    {
                                        target_Storage = Buildings.transform.GetChild(i).gameObject;
                                        target_Storage.GetComponent<Building_Info>().isTransporting = true;
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            Production p = target_Building.GetComponent<Production>();

                            if (p.is_Wood_Req())
                            {
                                if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Wood"))
                                {
                                    target_Storage = Buildings.transform.GetChild(i).gameObject;
                                    return true;
                                }
                            }
                            else if (p.is_Stone_Req())
                            {
                                if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Stone"))
                                {
                                    target_Storage = Buildings.transform.GetChild(i).gameObject;
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Checks to see if the storage have the required material.
    /// </summary>
    /// <param name="storage">GameObject Storage</param>
    /// <param name="name">Name of the material</param>
    /// <returns>
    /// true = found it.
    /// false = not fount it.
    /// </returns>
    bool has_Material(GameObject storage, string name)
    {
        if(storage.transform.FindChild(name) != null)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Checks to see if GameObject storage is empty or not of the building.
    /// </summary>
    /// <param name="target">GameObject storage</param>
    /// <returns>True = is greater than 0.
    ///          False = 0.
    /// </returns>
    bool check_Target_Building_Storage(GameObject target)
    {
        if(target.transform.childCount > 0)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Check if the Storage have space to keep materials.
    /// </summary>
    /// <param name="target">The Storage</param>
    /// <param name="limit">Storage limit</param>
    /// <returns></returns>
    bool check_Target_Storage_Storage(GameObject target, int limit)
    {
        if(target.transform.childCount < limit)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Checks to see if the target_Building.Storage is empty or not.
    /// </summary>
    /// <returns>True = Empty, False = Not Empty</returns>
    bool is_Target_Building_Empty()
    {
        if(target_Building.transform.FindChild("Storage").GetChildCount() == 0)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Picks up the produce
    /// </summary>
    void pick_Up_Produce()
    {
        int produce_NUM = target_Building.transform.FindChild("Storage").childCount;
        Weapon_Info wi = Weapon.GetComponent<Weapon_Info>();

        if (produce_NUM > 0)
        {
            if(produce_NUM <= wi.mat_Limit && produce_NUM > 0)
            {
                wi.Mat_NUM = produce_NUM;
                wi.Mat = (GameObject)Instantiate(target_Building.transform.FindChild("Storage").GetChild(0).gameObject, target_Building.transform.FindChild("Produce").position, target_Building.transform.FindChild("Produce").rotation);
                wi.Mat.SetActive(false);
                remove_Produce_From_TB(produce_NUM, target_Building.transform.FindChild("Storage").gameObject);
            }
            else if(produce_NUM > wi.mat_Limit)
            {
                wi.Mat_NUM = wi.mat_Limit;
                wi.Mat = (GameObject)Instantiate(target_Building.transform.FindChild("Storage").GetChild(0).gameObject, target_Building.transform.FindChild("Produce").position, target_Building.transform.FindChild("Produce").rotation);
                wi.Mat.SetActive(false);
                remove_Produce_From_TB(wi.mat_Limit, target_Building.transform.FindChild("Storage").gameObject);
            }
        }

        if(target_Building.GetComponent<Production>() != null)
        {
            target_Building.GetComponent<Production>().reset_Current();
        }

        target_Building.GetComponent<Building_Info>().isTransporting = false;
    }

    /// <summary>
    /// Searches for the produce required to make placed_Building.
    /// </summary>
    /// <returns>True = found, False = did not find</returns>
    bool pick_Up_Produce_For_PlacedBuilding()
    {
        int produce_NUM = target_Storage.transform.FindChild("Storage").childCount;
        Weapon_Info wi = Weapon.GetComponent<Weapon_Info>();
        Material_Required mr = target_Building.GetComponent<Material_Required>();

        if(produce_NUM > 0)
        {
            if (mr.is_Wood_Req())
            {
                if(loop_Pick_Up("Wood", produce_NUM, mr.get_Num_Wood_Req()))
                {
                    target_Storage.GetComponent<Building_Info>().isTransporting = false;
                    return true;
                }
            }
            else if (mr.is_Stone_Req())
            {
                if(loop_Pick_Up("Stone", produce_NUM, mr.get_Num_Stone_Req()))
                {
                    target_Storage.GetComponent<Building_Info>().isTransporting = false;
                    return true;
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Searches for the material required to make produce.
    /// </summary>
    /// <returns>True = found, False = did not find</returns>
    bool pick_Up_Produce_For_Production()
    {
        int produce_NUM = target_Storage.transform.FindChild("Storage").childCount;
        Weapon_Info wi = Weapon.GetComponent<Weapon_Info>();
        Production p = target_Building.GetComponent<Production>();

        if (produce_NUM > 0)
        {
            if (p.is_Wood_Req())
            {
                if (loop_Pick_Up("Wood", produce_NUM, p.get_Num_Wood_Req()))
                {
                    target_Storage.GetComponent<Building_Info>().isTransporting = false;
                    return true;
                }
            }
            else if (p.is_Stone_Req())
            {
                if (loop_Pick_Up("Stone", produce_NUM, p.get_Num_Stone_Req()))
                {
                    target_Storage.GetComponent<Building_Info>().isTransporting = false;
                    return true;
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Searchs for the produce in the target_Storage for picking up.
    /// </summary>
    /// <param name="produce_Name">Name of the produce.</param>
    /// <param name="storage_limit">Limit of the target_Storage.Storage</param>
    /// <param name="produce_Limit">Limit of the produce. How much produce should be taken.</param>
    /// <returns>True = found produce, False = did not find any.</returns>
    bool loop_Pick_Up(string produce_Name, int storage_limit, int produce_Limit)
    {
        int found_Produce = 0;
        Weapon_Info wi = Weapon.GetComponent<Weapon_Info>();

        for (int i = 0; i < storage_limit; i++)
        {
            if(target_Storage.transform.FindChild("Storage").GetChild(i).name == produce_Name)
            {
                if(found_Produce == 0)
                {
                    wi.Mat = (GameObject)Instantiate(target_Storage.transform.FindChild("Storage").GetChild(i).gameObject, target_Storage.transform.FindChild("Produce").position, target_Storage.transform.FindChild("Produce").rotation);
                    wi.Mat.SetActive(false);
                }

                Destroy(target_Storage.transform.FindChild("Storage").GetChild(i).gameObject);
                found_Produce++;
            }

            if (found_Produce >= produce_Limit)
            {
                break;
            }
        }

        if(found_Produce > 0)
        {
            wi.Mat_NUM = found_Produce;
            return true;
        }

        return false;
    }

    /// <summary>
    /// Drops the produce in the target_Storage
    /// </summary>
    bool drop_Produce()
    {
        GameObject temp = (GameObject)Instantiate(Weapon.GetComponent<Weapon_Info>().Mat, target_Storage.transform.FindChild("Produce").position, target_Storage.transform.FindChild("Produce").rotation);

        for (int i = 0; i < Weapon.GetComponent<Weapon_Info>().Mat_NUM; i++)
        {
            GameObject produce = (GameObject)Instantiate(temp, temp.transform.position, temp.transform.rotation);

            if (produce.GetComponent<Weapon_Info>() != null)
            {
                produce.transform.localScale = produce.transform.localScale * 50;
                produce.name = produce.GetComponent<Weapon_Info>().name;
            }
            else if (produce.GetComponent<Produce_Info>() != null)
            {
                produce.name = produce.GetComponent<Produce_Info>().name;

                if (produce.GetComponent<Produce_Info>().name == "Stone")
                {
                    produce.transform.localScale = produce.transform.localScale * 100;
                }
                //produce.transform.localScale = produce.transform.localScale * 50;
            }
            else if(produce.GetComponent<Food_Info>() != null)
            {
                produce.name = produce.GetComponent<Food_Info>().name;
                produce.transform.localScale = produce.transform.localScale * 50;
            }

            Destroy(Weapon.GetComponent<Weapon_Info>().Mat);
            produce.transform.parent = target_Storage.transform.FindChild("Storage");
            produce.SetActive(true);
        }

        Weapon.GetComponent<Weapon_Info>().Mat_NUM = 0;
        Destroy(temp);
        Weapon.GetComponent<Weapon_Info>().Mat = null;

        return true;
    }

    /// <summary>
    /// Drops the produce in placed_Building.
    /// </summary>
    void drop_Produce_PB()
    {
        GameObject temp = (GameObject)Instantiate(Weapon.GetComponent<Weapon_Info>().Mat, target_Building.transform.FindChild("Produce").position, target_Building.transform.FindChild("Produce").rotation);

        for (int i = 0; i < Weapon.GetComponent<Weapon_Info>().Mat_NUM; i++)
        {
            GameObject produce = (GameObject)Instantiate(temp, temp.transform.position, temp.transform.rotation);

            produce.name = produce.GetComponent<Produce_Info>().name;

            if (produce.GetComponent<Produce_Info>().name == "Stone")
            {
                produce.transform.localScale = produce.transform.localScale * 1;
            }

            produce.transform.parent = target_Building.transform.FindChild("Storage");
            produce.SetActive(true);
        }

        target_Building.GetComponent<Material_Required>().add_Mat(temp.GetComponent<Produce_Info>().name, Weapon.GetComponent<Weapon_Info>().Mat_NUM);

        Weapon.GetComponent<Weapon_Info>().Mat_NUM = 0;
        Destroy(Weapon.GetComponent<Weapon_Info>().Mat);
        Destroy(temp);
    }

    /// <summary>
    /// Drops the produce in placed_Building.
    /// </summary>
    void drop_Produce_Production()
    {
        GameObject temp = (GameObject)Instantiate(Weapon.GetComponent<Weapon_Info>().Mat, target_Building.transform.FindChild("Produce").position, target_Building.transform.FindChild("Produce").rotation);

        for (int i = 0; i < Weapon.GetComponent<Weapon_Info>().Mat_NUM; i++)
        {
            GameObject produce = (GameObject)Instantiate(temp, temp.transform.position, temp.transform.rotation);

            produce.name = produce.GetComponent<Produce_Info>().name;

            if (produce.GetComponent<Produce_Info>().name == "Stone")
            {
                produce.transform.localScale = produce.transform.localScale * 1;
            }

            produce.transform.parent = target_Building.transform.FindChild("Storage");
            produce.SetActive(true);
        }

        target_Building.GetComponent<Production>().add_Mat(temp.GetComponent<Produce_Info>().name, Weapon.GetComponent<Weapon_Info>().Mat_NUM);

        Weapon.GetComponent<Weapon_Info>().Mat_NUM = 0;
        Destroy(Weapon.GetComponent<Weapon_Info>().Mat);
        Destroy(temp);
    }

    /// <summary>
    /// Checks to see if the building has any produce items.
    /// </summary>
    /// <param name="storage">GameObject storage: checks this gameobject if it has produce</param>
    /// <returns>True = has produce, False = does not have produce.</returns>
    bool has_Produce(GameObject storage)
    {
        if(storage.transform.FindChild("Axe") != null || storage.transform.FindChild("Carry") != null || storage.transform.FindChild("Hammer") != null 
           || storage.transform.FindChild("Pickaxe") != null || storage.transform.FindChild("Bread") != null)
        {
            return true;
        }
        
        return false;
    }

    /// <summary>
    /// Removes the amount of produce taken from the storage of the target building.
    /// </summary>
    /// <param name="counter">int. How many children to remove from the storage.</param>
    /// <param name="storage">GameObject. The storage to remove from.</param>
    void remove_Produce_From_TB(int counter, GameObject storage)
    {
        for(int i = 0; i < counter; i++)
        {
            Destroy(storage.transform.GetChild(i).gameObject);
        }
    }

    //==================================END

    //==================================FOR PRODUCTION AI==============================//

    /// <summary>
    /// Checks if the AI type is a production AI
    /// </summary>
    /// <returns>True = production AI, False = Not production AI</returns>
    bool is_Production_AI()
    {
        if(ci.job_Type == Citizen_Info.JOB_TYPE.TOOLMAKER_AXE || ci.job_Type == Citizen_Info.JOB_TYPE.TOOLMAKER_BAGPACK || ci.job_Type == Citizen_Info.JOB_TYPE.TOOLMAKER_HAMMER
            || ci.job_Type == Citizen_Info.JOB_TYPE.TOOLMAKER_PICKAXE)
        {
            return true;
        }

        return false;
    }

    //==================================END============================================//

    bool is_Farmer_AI()
    {
        if(ci.job_Type == Citizen_Info.JOB_TYPE.FARMER_WHEAT)
        {
            return true;
        }

        return false;
    }

    bool is_Gatherer_AI()
    {
        if(ci.job_Type == Citizen_Info.JOB_TYPE.LUMBERJACK || ci.job_Type == Citizen_Info.JOB_TYPE.STONECUTTER)
        {
            return true;
        }

        return false;
    }

    bool is_Cook_AI()
    {
        if(ci.job_Type == Citizen_Info.JOB_TYPE.BAKER)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Picks up material from the work building.
    /// </summary>
    void pick_Up_Material()
    {
        int produce_NUM = work_Building.transform.FindChild("Storage").childCount;
        Weapon_Info wi = Weapon.GetComponent<Weapon_Info>();

        if (produce_NUM > 0)
        {
            if (produce_NUM <= wi.mat_Limit && produce_NUM > 0)
            {
                wi.Mat_NUM = produce_NUM;
                wi.Mat = (GameObject)Instantiate(work_Building.transform.FindChild("Storage").GetChild(0).gameObject, work_Building.transform.FindChild("Produce").position, work_Building.transform.FindChild("Produce").rotation);
                //TODO: This may create problem in futer try to fix it. <--------------------------------------------HERE!!!!!
                if (wi.Mat.GetComponent<Weapon_Info>() != null)
                {
                    wi.Mat.name = wi.Mat.GetComponent<Weapon_Info>().name;
                }
                else if (wi.Mat.GetComponent<Food_Info>() != null)
                {
                    wi.Mat.name = wi.Mat.GetComponent<Food_Info>().name;
                }

                wi.Mat.SetActive(false);
                remove_Produce_From_TB(produce_NUM, work_Building.transform.FindChild("Storage").gameObject);
            }
            else if (produce_NUM > wi.mat_Limit)
            {
                wi.Mat_NUM = wi.mat_Limit;
                wi.Mat = (GameObject)Instantiate(work_Building.transform.FindChild("Storage").GetChild(0).gameObject, work_Building.transform.FindChild("Produce").position, work_Building.transform.FindChild("Produce").rotation);
                //TODO: This may create problem in futer try to fix it. <--------------------------------------------HERE!!!!!
                if (wi.Mat.GetComponent<Weapon_Info>() != null)
                {
                    wi.Mat.name = wi.Mat.GetComponent<Weapon_Info>().name;
                }
                else if (wi.Mat.GetComponent<Food_Info>() != null)
                {
                    wi.Mat.name = wi.Mat.GetComponent<Food_Info>().name;
                }

                wi.Mat.SetActive(false);
                remove_Produce_From_TB(wi.mat_Limit, work_Building.transform.FindChild("Storage").gameObject);
            }
        }

        if (work_Building.GetComponent<Production>() != null)
        {
            work_Building.GetComponent<Production>().reset_Current();
        }

        work_Building.GetComponent<Building_Info>().isTransporting = false;
    }

    /// <summary>
    /// Searches for the material required to make produce.
    /// </summary>
    /// <returns>True = found, False = did not find</returns>
    bool pick_Up_Produce_Production()
    {
        int produce_NUM = target_Storage.transform.FindChild("Storage").childCount;
        Weapon_Info wi = Weapon.GetComponent<Weapon_Info>();
        Production p = work_Building.GetComponent<Production>();

        if (produce_NUM > 0)
        {
            if (p.is_Wood_Req())
            {
                if (loop_Pick_Up("Wood", produce_NUM, p.get_Num_Wood_Req()))
                {
                    target_Storage.GetComponent<Building_Info>().isTransporting = false;
                    return true;
                }
            }
            else if (p.is_Stone_Req())
            {
                if (loop_Pick_Up("Stone", produce_NUM, p.get_Num_Stone_Req()))
                {
                    target_Storage.GetComponent<Building_Info>().isTransporting = false;
                    return true;
                }
            }
            else if (p.is_Flour_Req())
            {
                if (loop_Pick_Up("Flour", produce_NUM, p.get_Num_Flour_Req()))
                {
                    target_Storage.GetComponent<Building_Info>().isTransporting = false;
                    return true;
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Drops the produce in work building.
    /// </summary>
    void drop_Produce_Production_2()
    {
        GameObject temp = (GameObject)Instantiate(Weapon.GetComponent<Weapon_Info>().Mat, work_Building.transform.FindChild("Produce").position, work_Building.transform.FindChild("Produce").rotation);

        for (int i = 0; i < Weapon.GetComponent<Weapon_Info>().Mat_NUM; i++)
        {
            GameObject produce = (GameObject)Instantiate(temp, temp.transform.position, temp.transform.rotation);

            produce.name = produce.GetComponent<Produce_Info>().name;

            if (produce.GetComponent<Produce_Info>().name == "Stone" || produce.GetComponent<Produce_Info>().name == "Flour")
            {
                produce.transform.localScale = produce.transform.localScale * 1;
            }
            
            produce.transform.parent = work_Building.transform.FindChild("Storage");
            //produce.transform.localScale = produce.transform.localScale * work_Building.transform.FindChild("Storage").localScale.x;
            produce.SetActive(true);
        }

        work_Building.GetComponent<Production>().add_Mat(temp.GetComponent<Produce_Info>().name, Weapon.GetComponent<Weapon_Info>().Mat_NUM);

        Weapon.GetComponent<Weapon_Info>().Mat_NUM = 0;
        Destroy(Weapon.GetComponent<Weapon_Info>().Mat);
        Destroy(temp);
    }

    /// <summary>
    /// Search for the building with food.
    /// </summary>
    /// <returns>True = food found, False = food not found.</returns>
    bool search_Food()
    {
        for(int i = 0; i < Buildings.transform.childCount; i++)
        {
            if (is_Building_Food_Production(Buildings.transform.GetChild(i).gameObject) || Buildings.transform.GetChild(i).name == "Storage")
            {
                if (Buildings.transform.GetChild(i).FindChild("Storage") != null)
                {
                    if (check_Target_Building_Storage(Buildings.transform.GetChild(i).FindChild("Storage").gameObject))
                    {
                        for (int j = 0; j < Buildings.transform.GetChild(i).FindChild("Storage").childCount; j++)
                        {
                            if (Buildings.transform.GetChild(i).FindChild("Storage").GetChild(j).GetComponent<Food_Info>() != null)
                            {
                                stat_GameObject = Buildings.transform.GetChild(i).gameObject;
                                return true;
                            }
                        }
                    }
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Checks to see if the building is a food production building.
    /// </summary>
    /// <param name="building">GameObject building that is going to be checked.</param>
    /// <returns>True = building is a food production building, false = not</returns>
    bool is_Building_Food_Production(GameObject building)
    {
        if(building.GetComponent<Building_Info>().building_Type == Building_Info.BUILDING_TYPE.BAKERY)
        {
            return true;
        }

        return true;
    }

    /// <summary>
    /// Eats the food in the storage of the building.
    /// </summary>
    /// <returns>True = ate the food.</returns>
    bool eat_Food()
    {
        if(stat_GameObject.transform.FindChild("Storage").childCount > 0)
        {
            for(int i = 0; i < stat_GameObject.transform.FindChild("Storage").childCount; i++)
            {
                if(stat_GameObject.transform.FindChild("Storage").GetChild(i).GetComponent<Food_Info>() != null)
                {
                    Food_Info fi = stat_GameObject.transform.FindChild("Storage").GetChild(i).GetComponent<Food_Info>();
                    ci.replenish_Energy(fi.energy);
                    ci.replenish_Hunger(fi.hunger);
                    ci.replenish_Entertainment(fi.entertainment);
                    fi.eat();
                    return true;
                }
            }
        }
        return false;
    }

    /// <summary>
    /// Search for a building which has some produce. (Version 2)
    /// </summary>
    /// <returns>True = has the produce, False = does not have it.</returns>
    bool search_Target_Storage_Produce_2(bool isPlacedBuild)
    {
        for (int i = 0; i < Buildings.transform.childCount; i++)
        {
            if (Buildings.transform.GetChild(i).GetComponent<Building_Info>().material_Type != Building_Info.MATERIAL_TYPE.PRODUCTION)
            {
                if (Buildings.transform.GetChild(i).FindChild("Storage") != null)
                {
                    if (check_Target_Building_Storage(Buildings.transform.GetChild(i).FindChild("Storage").gameObject))
                    {
                        if (isPlacedBuild)
                        {
                            if (!is_Target_Building_Destroyed())
                            {
                                Material_Required mr = target_Building.GetComponent<Material_Required>();

                                if (mr.is_Wood_Req())
                                {
                                    if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Wood"))
                                    {
                                        target_Storage = Buildings.transform.GetChild(i).gameObject;
                                        target_Storage.GetComponent<Building_Info>().isTransporting = true;
                                        return true;
                                    }
                                }
                                else if (mr.is_Stone_Req())
                                {
                                    if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Stone"))
                                    {
                                        target_Storage = Buildings.transform.GetChild(i).gameObject;
                                        target_Storage.GetComponent<Building_Info>().isTransporting = true;
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            Production p = work_Building.GetComponent<Production>();

                            if (p.is_Wood_Req())
                            {
                                if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Wood"))
                                {
                                    target_Storage = Buildings.transform.GetChild(i).gameObject;
                                    return true;
                                }
                            }
                            else if (p.is_Stone_Req())
                            {
                                if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Stone"))
                                {
                                    target_Storage = Buildings.transform.GetChild(i).gameObject;
                                    return true;
                                }
                            }
                            else if (p.is_Flour_Req())
                            {
                                if (has_Material(Buildings.transform.GetChild(i).FindChild("Storage").gameObject, "Flour"))
                                {
                                    target_Storage = Buildings.transform.GetChild(i).gameObject;
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Plants the seed.
    /// </summary>
    void plant_Seed()
    {
        GameObject temp = (GameObject)Instantiate(work_Building.GetComponent<Production_Farmer>().seed,
                                                  work_Building.GetComponent<Production_Farmer>().get_Cur_Plant_Pos().transform.position,
                                                  work_Building.GetComponent<Production_Farmer>().get_Cur_Plant_Pos().transform.rotation);

        temp.transform.parent = work_Building.GetComponent<Production_Farmer>().Farm.transform;
        temp.name = temp.GetComponent<Material_Info>().name;
    }

    //Teleports the citizen to the Action gameobject of the building.
    void teleport_To_Action()
    {
        transform.position = work_Building.transform.FindChild("Action").transform.position;
        ci.is_In_Action = true;
    }

    void teleport_To_Entrance()
    {
        transform.position = work_Building.transform.FindChild("Entrance").transform.position;
        ci.is_In_Action = false;
    }

    /// <summary>
    /// Teleports to the entrance of the placed building which is the last building in the Buildings.
    /// </summary>
    void teleport_To_Entrance_PB()
    {
        transform.position = Buildings.transform.GetChild(Buildings.transform.childCount - 1).FindChild("Entrance").position;
        ci.is_In_Action = false;
    }

    void Look_At_Target(GameObject target) {
        transform.LookAt(new Vector3(target.transform.position.x, 0, target.transform.position.z));
    }

    void increase_Visit_Count() {
        visit_Count++;
    }

    void increment_Count_Target_Building()
    {
        count_Target_Building++;

        if(count_Target_Building >= Buildings.transform.childCount)
        {
            count_Target_Building = 0;
        }
    }

    void idle_Me()
    {
        anim.SetBool("idle", true);
        anim.SetBool("walk", false);
        anim.SetBool("cut_tree", false);
        anim.SetBool("cut_stone", false);
    }

    /// <summary>
    /// Checks to see if weapon have anything in it.
    /// </summary>
    /// <returns>True = have mat, False = does not have any mats.</returns>
    bool has_Weapon_Mat()
    {
        if(Weapon.GetComponent<Weapon_Info>().Mat_NUM > 0)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Checks to see if the weapon have any produce in it.
    /// </summary>
    /// <returns>True = has produce, False = does not have produce.</returns>
    bool has_Weapon_Produce()
    {
        if (Weapon.GetComponent<Weapon_Info>().Mat != null)
        {
            if (Weapon.GetComponent<Weapon_Info>().Mat.name == work_Building.GetComponent<Production>().produce.name)
            {
                return true;
            }
        }

        return false;
    }
}