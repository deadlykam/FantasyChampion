#How to Play: #
You can move around using WASD and look around using mouse. Press 'B' to bring up the Build option. Press 'F' to place the building in real world. Try first to make a lumbercamp, stonemasionry and blacksmith hammer respectively. This way then your town will flourish. After that do as you wish. Remember once you select a building to build do place it other wise the temp building will remain in the game world. Also try to push the AIs around if they get stuck. Will fix the AI path later. Left mouse button shots fireball which does nothing right now. Holding down 'Left Shift' button will make you run though keep an eye out for stamina. Once the stamina is finished you won't be able to run again unless it replenishes again. 

Hope you enjoy :)

K Out!

# Things To Do: #

1. Create Player Model. -DONE
2. Create Stage Model. -DONE
3. Create Citizen Models. -DONE
4. Create Enemy Models.
5. Create Building Models. -DONE
6. Player Movement. -DONE
7. Player Anim 1. -DONE
8. Player Anim 2 (include Attack). -DONE
9. Run Effect.
10. Shoots projectiles. -DONE
11. Hand Effects.
12. Player Anim 3 (include Attack).
13. Creating HUD. -DONE
14. Adding Health Bar. -DONE
15. Adding Stamina Bar. -DONE
16. Place holder artifact. -DONE
17. Place holder artifact FX.
18. Place holder artifact healing and stamina repelishment. -DONE
19. Placing buildings. -DONE
20. Auto connect two buildings with road. -NOT NEEDED
21. Player Buff Effects.
22. Portals.
23. Enemy Model.
24. Enemy Attacking.
25. Tower Model.
26. Tower Attacking.
27. Enemy Dying.
28. Tower Dying.
29. Generating Enemies.

Latest starts from here.
30. Citizen path finding or obstacle detection.
31. Add more mats.
32. Citizen generation. -DONE
33. More texture for terrain.
34. Storage. -DONE
35. Mats required for buildings. -DONE
36. Engineers. -DONE
37. Mat transfer. -DONE.
38. Production requires mat too. -DONE
39. Transferring mats from buildings to storage. -DONE
40. Don't go to building which is filled up or when someone else is going. -DONE
41. Eliminate Blacksmith and make different type of buildings for each items. -DONE
42. Keep produce records in buildings. -DONE
43. Creating walls.
44. World Prefabs, stores all the prefabs needed by the citizens.
45. Remove transport AI and make other AI do the their individual transporting. -DONE
46. Keep storage mats record in Storage.
47. Separate Gatherer AI. -DONE
48. Enable/Disable a building. -DONE
49. Can rotate the temp building. -DONE
50. Fix scaling issue.
51. House for generating citizens. -DONE
52. Move to the first free spot job building, not visit all.
53. Grow produce like wheat, trees etc. -DONE
54. Citizens get hungry. -DONE
55. Citizens get tired. -DONE
56. Citizens needs food, sleep, entertainments etc. -DONE
57. Citizen works require energy. -DONE
58. Make wheat farm. -DONE
59. Make bakery. -DONE
60. Fix energy replenishment, make sure the ones inside buildings can get out. -DONE
61. Show Citizen stats. -DONE
62. Delete option for buildings.
63. Delete option for placed buildings.
64. Delete option for citizens.
65. Bakery work smoke simulation.
66. Show placed building stats. -DONE
67. Engineer jumps to entrance once building is done makeing. -DONE
68. Can give speed buff to Citizen.
69. Show tooltip for buildings in build menu.