﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

/// <summary>
/// This class handle the connection between Build_UI and other Gameobjects.
/// </summary>

public class Player_Action : MonoBehaviour {

    public enum OBJECT_TYPE { NONE, BUILDING, CITIZEN };

    public bool isPanels = false;

    //======================================== This is for BuildingInfo_Panel ONLY!!!!===========================================//
    public GameObject BuildingInfo_Panel;
    public Text Name_Text;
    public Text Workers_Text;
    public Text Storage_Text;
    public Text enable_Disable;

    //Button Panel
    public GameObject Button_Panel;
    public Button button_1;

    private Building_Info bi;
    //======================================== End!!!!===========================================//

    //======================================== This is for Citizen Stat Only!!!=================================================//
    public GameObject Citizen_Stat_Panel;
    public Slider energy;
    public Slider hunger;
    public Slider entertainment;

    private Citizen_Info ci;
    //======================================== End!!!============================================//

    //======================================== This is for Placed Building Only!!!==============================================//
    public GameObject PlacedBuilding_Panel;
    public Text Name_Text_PB;
    public Text Worker_Text_PB;
    public Text Wood_PB;
    public Text Stone_PB;

    private Material_Required mr;
    //======================================== End!!!============================================//

    public Text message;

    private bool action_Enable = false;
    private OBJECT_TYPE object_Type = OBJECT_TYPE.NONE;
    private Building_Info.MATERIAL_TYPE material_Type = Building_Info.MATERIAL_TYPE.NONE;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        PressAction();

        if (Citizen_Stat_Panel.activeSelf)
        {
            update_Citizen_Stat();
        }
	}

    void PressAction()
    {
        if (bi != null)
        {
            if (bi.active)
            {
                if (Input.GetButtonDown("Action"))
                {
                    if (!BuildingInfo_Panel.active)
                    {
                        BuildingInfo_Panel.SetActive(true);
                        Setup_Info();

                        isPanels = true;
                    }
                    else
                    {
                        BuildingInfo_Panel.SetActive(false);
                        Button_Panel.SetActive(false);
                        isPanels = false;
                    }
                }
            }
        }
        else if(ci != null)
        {
            if (Input.GetButtonDown("Action"))
            {
                if (!Citizen_Stat_Panel.activeSelf)
                {
                    energy.value = ci.energy;
                    hunger.value = ci.hunger;
                    entertainment.value = ci.entertainment;
                    Citizen_Stat_Panel.SetActive(true);
                }
                else
                {
                    Citizen_Stat_Panel.SetActive(false);
                }
            }
        }
        else if(mr != null)
        {
            if (Input.GetButtonDown("Action"))
            {
                if (!PlacedBuilding_Panel.activeSelf)
                {
                    Name_Text_PB.text = mr.name;
                    Worker_Text_PB.text = mr.free_Spot_Engineer + "/" + mr.max_Spot_Engineer;
                    Wood_PB.text = mr.c_Wood + "/" + mr.max_Wood;
                    Stone_PB.text = mr.c_Stone + "/" + mr.max_Stone;
                    PlacedBuilding_Panel.SetActive(true);
                }
                else
                {
                    PlacedBuilding_Panel.SetActive(false);
                }
            }
        }
    }

    void update_Citizen_Stat()
    {
        energy.value = ci.energy;
        hunger.value = ci.hunger;
        entertainment.value = ci.entertainment;
    }

    void Setup_Info()
    {
        if(object_Type == OBJECT_TYPE.BUILDING)
        {
            Name_Text.text = bi.name;
            Workers_Text.text = bi.free_Spots + "/" + bi.max_Spots;
            if (bi.storage != null) {
                Storage_Text.text = bi.storage.transform.childCount  + "/" + bi.storage_Limit;
            }
        }
    }

    //Input comes from Button_Panel.
    public void Select_Production(int index)
    {
        bi.produce(index);
    }

    public void setup_Building_Activation()
    {
        bi.enable = !bi.enable;

        if (bi.enable)
        {
            enable_Disable.text = "Disable";
        }
        else
        {
            enable_Disable.text = "Enable";
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponentInParent<Building_Info>() != null)
        {
            bi = other.GetComponentInParent<Building_Info>();

            if (bi.active)
            {
                message.text = "Press 'E' to get info of " + bi.name;

                action_Enable = true;
                object_Type = OBJECT_TYPE.BUILDING;
                material_Type = bi.material_Type;
            }
            else
            {
                message.text = "No worker is present at this building.";
            }
        }
        else if(other.GetComponentInParent<Citizen_Info>() != null)
        {
            ci = other.GetComponentInParent<Citizen_Info>();
            message.text = "Press 'E' to get info of your citizen.";
        }
        else if(other.GetComponentInParent<Material_Required>() != null)
        {
            mr = other.GetComponentInParent<Material_Required>();
            message.text = "Press 'E' to get info of " + mr.name;
        }
    }

    void OnTriggerExit(Collider other)
    {
        bi = null;
        BuildingInfo_Panel.SetActive(false);
        action_Enable = false;
        isPanels = false;

        ci = null;
        Citizen_Stat_Panel.SetActive(false);

        mr = null;
        PlacedBuilding_Panel.SetActive(false);
        
        message.text = "";
    }
}
