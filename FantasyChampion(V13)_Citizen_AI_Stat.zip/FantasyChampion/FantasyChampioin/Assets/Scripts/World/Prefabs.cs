﻿using UnityEngine;
using System.Collections;

public class Prefabs : MonoBehaviour {
    GameObject[] items;
    GameObject[] materials;

    /// <summary>
    /// Search for the item using item name
    /// </summary>
    /// <param name="name">Name of the item</param>
    /// <returns>GameObject: returns the gameobject with weapon.name = name</returns>
    public GameObject getItem(string name)
    {
        for(int i = 0; i < items.Length; i++)
        {
            Weapon_Info wi = items[i].GetComponent<Weapon_Info>();

            if(wi.name == name)
            {
                return items[i];
            }
        }

        return null;
    }
}
