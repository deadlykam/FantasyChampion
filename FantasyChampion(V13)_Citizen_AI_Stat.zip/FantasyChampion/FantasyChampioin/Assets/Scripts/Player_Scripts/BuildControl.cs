﻿using UnityEngine;
using System.Collections;

public class BuildControl : MonoBehaviour {

    public enum BUILD_MODE { NONE, BUILD, TREE };

    public GameObject [] prefab_Temp;
    public GameObject [] prefab_Main;
    public GameObject prefab_Sign;
    public GameObject Placed_Buildings;
    public GameObject Signs;
    public GameObject Build_Panel;
    public BUILD_MODE build_mode = BUILD_MODE.NONE;
    public float rotate_Speed;

    private GameObject temp;

    //ReadOnly Variables
    private readonly string BUILD_MODE_BUILDING = "BUILDING";
    private readonly string BUILD_MODE_TREE = "TREE";
    
    private int building_Number = 0;

    // Use this for initialization
    void Start () {

	}
	
	// Update is called once per frame
	void Update () {
        //build_Mode_Status();
        build_Mode_Pop_Up();
        temp_Object();
        temp_Rotate();
        place_Object();
	}

    //Build pop up menu.
    void build_Mode_Pop_Up()
    {
        if (Input.GetButtonDown("Build")){
            if (build_mode == BUILD_MODE.NONE)
            {
                if (!Build_Panel.activeSelf)
                {
                    Build_Panel.SetActive(true);
                }
                else
                {
                    Build_Panel.SetActive(false);

                    if (!is_Temp_Null())
                    {
                        remove_Temp();
                    }
                }
            }
            else
            {
                build_mode = BUILD_MODE.NONE;
                if (!is_Temp_Null())
                {
                    remove_Temp();
                }
            }
        }
    }

    //Input comes from buttons in Build_UI.
    public void select_Building(int building_Number)
    {
        build_mode = BUILD_MODE.BUILD;
        this.building_Number = building_Number;
        temp = Instantiate(prefab_Temp[building_Number]);
        Build_Panel.SetActive(false);
    }

    /// <summary>
    /// Removes the temp GameObject
    /// </summary>
    void remove_Temp()
    {
        Destroy(temp);
    }

    /// <summary>
    /// Checks if the temp object is null or not
    /// </summary>
    /// <returns>True = null, False = Not null</returns>
    bool is_Temp_Null()
    {
        if(temp == null)
        {
            return true;
        }

        return false;
    }

    //Toggling and removing temp object.
    void build_Mode_Status()
    {
        if (Input.GetButtonDown("Build") && (build_mode == BUILD_MODE.NONE || build_mode == BUILD_MODE.BUILD))
        {
            toggle_Build_Mode(BUILD_MODE_BUILDING);

            if (build_mode == BUILD_MODE.BUILD)
            {
                temp = Instantiate(prefab_Temp[0]); //<--- Fix this now!
            }
            else
            {
                Destroy(temp);
            }
        }

        //This part may be depricated in future.
        if(Input.GetButtonDown("Tree") && (build_mode == BUILD_MODE.NONE || build_mode == BUILD_MODE.TREE))
        {
            toggle_Build_Mode(BUILD_MODE_TREE);

            if(build_mode == BUILD_MODE.TREE)
            {
                temp = Instantiate(prefab_Sign);
            }
            else
            {
                Destroy(temp);
            }
        }
    }

    //Moving around temp object.
    void temp_Object()
    {
        if (build_mode == BUILD_MODE.BUILD)
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                if (hit.transform.gameObject.layer == LayerMask.NameToLayer("Ground"))
                {
                    temp.transform.position = hit.point;
                }
            }
        }

        if(build_mode == BUILD_MODE.TREE)
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                temp.transform.position = hit.point;
            }
        }
    }

    void temp_Rotate()
    {
        if (build_mode == BUILD_MODE.BUILD)
        {
            if (Input.GetAxisRaw("Mouse ScrollWheel") > 0)
            {
                /*Quaternion q = new Quaternion();
                q.eulerAngles = new Vector3(0, temp.transform.rotation.y + 100, 0);
                temp.transform.rotation = Quaternion.Lerp(temp.transform.rotation, q, Time.deltaTime * rotate_Speed);*/

                temp.transform.Rotate(new Vector3(0, rotate_Speed, 0) * Time.deltaTime);
            }
            else if (Input.GetAxisRaw("Mouse ScrollWheel") < 0)
            {
                /*Quaternion q = new Quaternion();
                q.eulerAngles = new Vector3(0, temp.transform.rotation.y - 100, 0);
                temp.transform.rotation = Quaternion.Lerp(temp.transform.rotation, q, Time.deltaTime * rotate_Speed);*/

                temp.transform.Rotate(new Vector3(0, -rotate_Speed, 0) * Time.deltaTime);
            }
        }
    }

    //Place temp object.
    //Re-write the code here. Does not require to create it twice.
    void place_Object()
    {
        if (Input.GetButtonDown("Place"))
        {
            if (build_mode == BUILD_MODE.BUILD)
            {
                Vector3 newPos = temp.transform.position;
                newPos.y = newPos.y + 0.01f;

                GameObject placement = (GameObject)Instantiate(prefab_Main[building_Number], newPos, temp.transform.rotation); //<--- Fix this now!
                placement.name = placement.GetComponent<Material_Required>().name;
                placement.transform.parent = Placed_Buildings.transform;
                build_mode = BUILD_MODE.NONE;
                Destroy(temp);
            }

            if(build_mode == BUILD_MODE.TREE)
            {
                GameObject placement = (GameObject)Instantiate(prefab_Sign, temp.transform.position, temp.transform.rotation);
                placement.transform.parent = Signs.transform;
                build_mode = BUILD_MODE.NONE;
                Destroy(temp);
            }
        }
    }

    void toggle_Build_Mode(string type)
    {
        if(type == BUILD_MODE_BUILDING)
        {
            if (build_mode == BUILD_MODE.BUILD)
            {
                build_mode = BUILD_MODE.NONE;
            }
            else
            {
                build_mode = BUILD_MODE.BUILD;
            }
        }

        if (type == BUILD_MODE_TREE)
        {
            if (build_mode == BUILD_MODE.TREE)
            {
                build_mode = BUILD_MODE.NONE;
            }
            else
            {
                build_mode = BUILD_MODE.TREE;
            }
        }
    }
}
