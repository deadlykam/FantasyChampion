﻿using UnityEngine;
using System.Collections;

public class Food_Info : MonoBehaviour {
    public string name;
    public float energy;
    public float hunger;
    public float entertainment;

    public void eat()
    {
        Destroy(gameObject);
    }
}
