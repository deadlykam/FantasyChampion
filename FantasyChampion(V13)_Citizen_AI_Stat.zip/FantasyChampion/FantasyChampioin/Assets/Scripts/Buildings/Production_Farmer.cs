﻿using UnityEngine;
using System.Collections;

public class Production_Farmer : MonoBehaviour {

    public GameObject seed;
    public GameObject Farm;

    int num_Plant_Spots;
    int cur_Plant_Pos;

	// Use this for initialization
	void Start () {
        num_Plant_Spots = transform.FindChild("Locs").childCount;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    /// <summary>
    /// Checks to see if all the seeds have grown.
    /// </summary>
    /// <returns>True = all grown up, False = not grown.</returns>
    public bool is_All_Grown()
    {
        bool grown = true;

        for(int i = 0; i < Farm.transform.childCount; i++)
        {
            if (!Farm.transform.GetChild(i).GetComponent<Material_Info>().is_Grown())
            {
                grown = false;
                break;
            }
        }

        return grown;
    }

    /// <summary>
    /// Checks to see if farm have any seeds in it.
    /// </summary>
    /// <returns>True = Farm is empty, False = Farm is not empty</returns>
    public bool is_All_Dead()
    {
        if(Farm.transform.childCount == 0)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Checks to see if all planting spots have been planted.
    /// </summary>
    /// <returns>True = planted all spots, False = not planted all spots.</returns>
    public bool is_All_Planted()
    {
        if(Farm.transform.childCount >= num_Plant_Spots)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// Gets the next available spot for planting.
    /// </summary>
    /// <returns>GameObject with the next spot to plant.</returns>
    public GameObject get_Cur_Plant_Pos()
    {
        return transform.FindChild("Locs").GetChild(cur_Plant_Pos).gameObject;
    }

    /// <summary>
    /// Gets the first abvailable seed.
    /// </summary>
    /// <returns>GameObject which is the first available seed.</returns>
    public GameObject get_Material_GO()
    {
        return transform.FindChild("Farm").GetChild(0).gameObject;
    }

    /// <summary>
    /// Gets the next spot index in Locs.
    /// </summary>
    public void next_Spot()
    {
        cur_Plant_Pos++;

        if(cur_Plant_Pos >= num_Plant_Spots)
        {
            cur_Plant_Pos = 0;
        }
    }
}
