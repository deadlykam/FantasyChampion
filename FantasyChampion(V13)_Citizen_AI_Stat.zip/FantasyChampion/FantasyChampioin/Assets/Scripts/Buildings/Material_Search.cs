﻿using UnityEngine;
using System.Collections;

public class Material_Search : MonoBehaviour {

    private Building_Info bi;

    //Tag Names
    private readonly string tag_TREE = "Tree";
    private readonly string tag_STONE = "Stone";

    // Use this for initialization
    void Start () {
        bi = GetComponentInParent<Building_Info>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    /*void OnTriggerEnter(Collider other)
    {
        if(bi.material_Type == Building_Info.MATERIAL_TYPE.TREE)
        {
            if (other.CompareTag(tag_TREE))
            {
                //Debug.Log("Inside collider: " + other.tag);
                bi.set_TargetMaterial(other.transform.gameObject);
            }
        }
    }*/

    void OnTriggerStay(Collider other)
    {
        if (bi.get_TargetMaterial() == null)
        {
            if (bi.material_Type == Building_Info.MATERIAL_TYPE.TREE)
            {
                if (other.CompareTag(tag_TREE))
                {
                    //Debug.Log("Inside collider: " + other.tag);
                    bi.set_TargetMaterial(other.transform.gameObject);
                }
            }
            else if (bi.material_Type == Building_Info.MATERIAL_TYPE.STONE)
            {
                //Debug.Log("Searching for stone!");
                if (other.CompareTag(tag_STONE))
                {
                    //Debug.Log("Inside collider: " + other.tag);
                    bi.set_TargetMaterial(other.transform.gameObject);
                }
            }
        }

        //Debug.Log("other name: " + other.tag);
    }
}
