﻿using UnityEngine;
using System.Collections;

public class Weapon_Info : MonoBehaviour {

    public string name;
    public float damage;
    public int process_Time;
    public bool collect_Mat = false;

    //Tranporter
    private GameObject mat;
    private int mat_NUM;
    public int mat_Limit;

    private int current_Process_Time = 0;


    public void reset_Current_Process_Time()
    {
        current_Process_Time = 0;
    }

    public void add_Process()
    {
        current_Process_Time++;

        if(current_Process_Time >= process_Time)
        {
            //Debug.Log("Collect Mat!");
            collect_Mat = true;
            reset_Current_Process_Time();
        }
    }
    
    public GameObject Mat
    {
        get
        {
            return mat;
        }

        set
        {
            mat = value;
        }
    }

    public int Mat_NUM
    {
        get
        {
            return mat_NUM;
        }

        set
        {
            mat_NUM = value;
        }
    }
}
