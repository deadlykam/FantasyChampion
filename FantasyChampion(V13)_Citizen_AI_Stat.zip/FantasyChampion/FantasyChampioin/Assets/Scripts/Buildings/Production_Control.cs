﻿using UnityEngine;
using System.Collections;

public class Production_Control : MonoBehaviour {

    public GameObject [] produce;
    
}
