﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {

    public float speed_Walk = 1f;
    public float speed_Run = 1f;
    public float speed_Turn = 1f;
    public float ver_Min = 0;
    public float ver_Max = 0;

    private GameObject pivot;
    private Animator anim;
    private Player_Info pi;
    private PlayerAttack pa;
    private Player_Action p_a;

	// Use this for initialization
	void Start () {
        anim = GetComponentInChildren<Animator>();
        pivot = transform.Find("Models").gameObject.transform.Find("Pivot").gameObject;

        pi = GetComponent<Player_Info>();
        pa = GetComponent<PlayerAttack>();
        p_a = transform.FindChild("Action_Range").GetComponent<Player_Action>();
	}
	
	// Update is called once per frame
	void Update () {
        if (!p_a.isPanels)
        {
            Move();
            Turn();
        }
	}

    void Move() {
        float forward = 0;
        if (Input.GetButton("L_Shift") && pi.isRun) {
            forward = Input.GetAxis("Vertical") * speed_Run * Time.deltaTime;
            pi.lowerStamina();
        }
        else {
            forward = Input.GetAxis("Vertical") * speed_Walk * Time.deltaTime;
        }
        
        float sideward = Input.GetAxis("Horizontal") * speed_Walk * Time.deltaTime;
        transform.Translate(sideward, 0, forward);

        if (!pa.isAttacking){
            if (forward > 0)
            {
                if (Input.GetButton("L_Shift") && pi.isRun)
                {
                    anim.SetBool("run", true);
                    anim.SetBool("walk", false);
                }
                else
                {
                    anim.SetBool("run", false);
                    anim.SetBool("walk", true);
                }

            }
            else
            {
                anim.SetBool("walk", false);
                anim.SetBool("run", false);
            }
        }
    }

    void Turn() {
        float horizantal = Input.GetAxis("Mouse X") * speed_Turn;
        float vertical = Input.GetAxis("Mouse Y") * -speed_Turn;

        transform.Rotate(0, horizantal, 0);

        Vector3 v_Rot = pivot.transform.localEulerAngles;
        v_Rot.x = Mathf.Clamp(v_Rot.x + vertical, ver_Min, ver_Max);
        pivot.transform.localEulerAngles = v_Rot;
    }
}
