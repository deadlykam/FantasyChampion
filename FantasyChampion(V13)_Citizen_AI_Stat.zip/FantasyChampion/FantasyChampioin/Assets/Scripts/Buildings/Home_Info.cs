﻿using UnityEngine;
using System.Collections;

public class Home_Info : MonoBehaviour {

    public GameObject citizen; //<--- Make this random in future
    public int max_Citizen;
    public int time_Delay;

    private GameObject Citizens;
    private int current_Citizen = 0;

	// Use this for initialization
	void Start () {
        Citizens = transform.root.FindChild("AIs").FindChild("Citizens").gameObject;
	}
	
	// Update is called once per frame
	void Update () {
	    if(current_Citizen < max_Citizen)
        {
            create_Citizen();
        }
	}

    void create_Citizen()
    {
        for(int i = current_Citizen; i < max_Citizen; i++)
        {
            //TODO: Implement delay here.
            GameObject temp = (GameObject)Instantiate(citizen, transform.FindChild("Entrance").position, transform.FindChild("Entrance").rotation);
            temp.name = temp.GetComponent<Citizen_Info>().name;
            temp.GetComponent<Citizen_AI>().home = gameObject;
            temp.transform.parent = Citizens.transform;
            current_Citizen++;
            
        }
    }

    //TODO: Create method that when a citizen dies current_Citizen-- after a certain time.
}
