﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Player_Bar_Controller : MonoBehaviour {
    public RectTransform health_Bar;
    public Text health_Text;
    private float store_X_Health;
    private float min_Y_Health;
    private float max_Y_Health;

    public RectTransform stamina_Bar;
    public Text stamina_Text;
    private float store_X_Stamina;
    private float min_Y_Stamina;
    private float max_Y_Stamina;

    //public Image bar_bar; //<--- Needed if only want to change the colour of the image.

    private Player_Info pi;
    

	// Use this for initialization
	void Start () {
        pi = GetComponent<Player_Info>();

        store_X_Health = health_Bar.position.x;
        max_Y_Health = health_Bar.position.y;
        min_Y_Health = health_Bar.position.y - health_Bar.rect.height;

        store_X_Stamina = stamina_Bar.position.x;
        max_Y_Stamina = stamina_Bar.position.y;
        min_Y_Stamina = stamina_Bar.position.y - stamina_Bar.rect.height;
	}
	
	// Update is called once per frame
	void Update () {
        BarUpdate();
        Buff_Text_Update();
	}

    void Buff_Text_Update()
    {
        //Health
        if (pi.GetHealthTimer() > 0)
        {
            health_Text.text = "" + pi.GetHealthTimer();
        }
        else
        {
            health_Text.text = "";
        }

        //Stamina
        if (pi.GetStaminaTimer() > 0)
        {
            stamina_Text.text = "" + pi.GetStaminaTimer();
        }
        else
        {
            stamina_Text.text = "";
        }
    }

    void BarUpdate() {
        health_Bar.position = new Vector3(store_X_Health, Calculate_Y_Pos(pi.health_Current, 0, pi.health_Max, max_Y_Health, min_Y_Health));
        stamina_Bar.position = new Vector3(store_X_Stamina, Calculate_Y_Pos(pi.stamina_Current, 0, pi.stamina_Max, max_Y_Stamina, min_Y_Stamina));
    }

    float Calculate_Y_Pos(float value_current, float value_Min, float value_Max, float max_Y, float min_Y)
    {
        return (value_current - value_Min) * (max_Y - min_Y) / (value_Max - value_Min) + min_Y;
    }
}
