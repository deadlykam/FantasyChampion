﻿using UnityEngine;
using System.Collections;

public class Projectiles_Info : MonoBehaviour {

    public float speed;
    public float damage;
    public float timer;
    public GameObject particle;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        Move();
        Timer();
	}

    void Move()
    {
        transform.Translate(Vector3.up * speed * Time.deltaTime);
    }

    void Timer()
    {
        timer -= Time.deltaTime;

        if (timer <= 0)
        {
            CreateExplosion();
            KillMe();
        }
    }

    void CreateExplosion()
    {
        GameObject particle_Clone = (GameObject)Instantiate(particle, transform.position, Quaternion.identity);
        particle_Clone.transform.position = transform.position;
        particle_Clone.transform.rotation = transform.rotation;
    }

    void KillMe()
    {
        Destroy(gameObject);
    }

    void OnTriggerEnter(Collider other)
    {
        if (!other.gameObject.CompareTag("Projectile_Player"))
        {
            CreateExplosion();
            KillMe();
        }
    }
}
