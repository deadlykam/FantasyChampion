﻿using UnityEngine;
using System.Collections;

public class Player_Production_Selector : MonoBehaviour {
    
    public void Select_Production(int index)
    {
        //TODO: send index to production.
    }
}
